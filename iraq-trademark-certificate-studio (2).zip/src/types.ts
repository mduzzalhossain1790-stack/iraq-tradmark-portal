export interface TrademarkCertificate {
  id: string; // Internal state ID
  registryNumber: string; // الرقم المتسلسل / التسجيل
  applicationNumber: string; // رقم الطلب
  applicationDate: string; // تاريخ تقديم الطلب
  registrationDate: string; // تاريخ التسجيل / النشر
  expiryDate: string; // تاريخ انتهاء الصلاحية
  journalNumber: string; // رقم جريدة العلامات
  journalPageNumber: string; // رقم الصفحة بالجريدة
  
  // Trademark details
  trademarkNameEn: string;
  trademarkNameAr: string;
  trademarkLogoUrl: string; // Base64 or preset logo identifier
  trademarkLogoName: string; // If custom file uploaded
  trademarkType: 'Word' | 'Device' | 'Composite' | 'Three-Dimensional'; // نوع العلامة
  trademarkTypeAr: string;
  
  // Classification
  niceClass: number; // فئة تصنيف نيس الدولي
  goodsDescriptionEn: string;
  goodsDescriptionAr: string;
  
  // Ownership details
  ownerNameEn: string;
  ownerNameAr: string;
  ownerNationalityEn: string;
  ownerNationalityAr: string;
  ownerAddressEn: string;
  ownerAddressAr: string;
  ownerLegalStatusEn: string; // e.g. Corporation, LLC, Partnership, Individual
  ownerLegalStatusAr: string;
  
  // Registration Authority / Signatures
  registrarNameEn: string;
  registrarNameAr: string;
  registrarTitleEn: string;
  registrarTitleAr: string;
  registrarSignatureOption: 'wet-ink' | 'stamp-only' | 'digital-only';
  
  // Security Features Enabled
  enableGoldSeal: boolean;
  enableRepublicRibbon: boolean;
  enableGuillocheBg: boolean;
  securityHash: string; // Fake or real cryptographic seal signature
  status?: 'Active' | 'Expired' | 'Pending'; // الرافد لحالة العلامة (نشطة، منتهية، معلقة)
}

export interface NiceClassPreset {
  classNumber: number;
  titleEn: string;
  titleAr: string;
  defaultGoodsEn: string;
  defaultGoodsAr: string;
}

export const NICE_CLASSES: NiceClassPreset[] = [
  {
    classNumber: 1,
    titleEn: "Chemicals",
    titleAr: "المواد الكيميائية",
    defaultGoodsEn: "Chemical preparations for industrial and scientific purposes, raw plastics, fertilizers.",
    defaultGoodsAr: "المستحضرات الكيميائية المخصصة للصناعة والعلوم، المواد البلاستيكية الخام، الأسمدة."
  },
  {
    classNumber: 3,
    titleEn: "Cosmetics & Cleaning",
    titleAr: "مستحضرات التجميل والتنظيف",
    defaultGoodsEn: "Non-medicated cosmetics, perfumes, essential oils, hair lotions, dentifrices, soaps.",
    defaultGoodsAr: "مستحضرات التجميل غير الطبية، العطور، الزيوت العطرية، لوشينات الشعر، معاجين الأسنان، الصابون."
  },
  {
    classNumber: 5,
    titleEn: "Pharmaceuticals",
    titleAr: "المستحضرات الصيدلانية",
    defaultGoodsEn: "Pharmaceuticals, medical and veterinary preparations, dietetic food adapted for medical use, baby food.",
    defaultGoodsAr: "المستحضرات الصيدلانية والطبية والبيطرية، الأغذية والمواد الغذائية المخصصة للاستخدام الطبي، أغذية الأطفال."
  },
  {
    classNumber: 9,
    titleEn: "Scientific & Digital",
    titleAr: "الأجهزة العلمية والتكنولوجية",
    defaultGoodsEn: "Computer software, mobile applications, scientific apparatus, electronic devices, telecommunications hardware.",
    defaultGoodsAr: "برامج الكمبيوتر، تطبيقات الهاتف المحمول، الأجهزة العلمية، الأجهزة الإلكترونية، أجهزة الاتصالات السلكية واللاسلكية."
  },
  {
    classNumber: 12,
    titleEn: "Vehicles",
    titleAr: "المركبات ووسائط النقل",
    defaultGoodsEn: "Vehicles, apparatus for locomotion by land, air or water, automotive parts.",
    defaultGoodsAr: "المركبات، أجهزة التنقل برًا أو جوًا أو بحرًا، قطع غيار السيارات."
  },
  {
    classNumber: 25,
    titleEn: "Clothing & Apparel",
    titleAr: "الملابس والملبوسات",
    defaultGoodsEn: "Clothing, footwear, headwear, athletic apparel, formal suits, traditional garments.",
    defaultGoodsAr: "الملابس، الأحذية، أغطية الرأس، الملابس الرياضية، البدلات الرسمية، الأزياء التقليدية التراثية."
  },
  {
    classNumber: 29,
    titleEn: "Meats & Processed Foods",
    titleAr: "اللحوم والأغذية المحفوظة",
    defaultGoodsEn: "Meat, fish, poultry and game, preserved, frozen, dried and cooked fruits and vegetables, dairy products.",
    defaultGoodsAr: "اللحوم والأسماك والدواجن والطيور البرية، الفواكه والخضروات المحفوظة أو المجمدة أو المجففة، منتجات الألبان."
  },
  {
    classNumber: 30,
    titleEn: "Coffee, Tea & Baked Goods",
    titleAr: "القهوة والشاي والمخبوزات",
    defaultGoodsEn: "Coffee, tea, cocoa and artificial coffee, rice, pasta, flour, bread, pastry, confectionery, chocolate.",
    defaultGoodsAr: "القهوة والشاي والكاكاو والقهوة الاصطناعية، الأرز، المعكرونة، الدقيق، الخبز، الحلويات، الشوكولاتة."
  },
  {
    classNumber: 32,
    titleEn: "Beverages & Water",
    titleAr: "المشروبات والمياه",
    defaultGoodsEn: "Beers, non-alcoholic beverages, mineral and aerated waters, fruit beverages and juices, syrups.",
    defaultGoodsAr: "البيرة والمشروبات غير الكحولية، المياه المعدنية والمقواة بالغاز، مشروبات وعصائر الفواكه، شراب السيروب."
  },
  {
    classNumber: 35,
    titleEn: "Advertising & Business",
    titleAr: "الإعلانات وإدارة الأعمال",
    defaultGoodsEn: "Advertising, business management, marketing, commercial administration, office functions, retail services.",
    defaultGoodsAr: "الدعاية والإعلان، إدارة الأعمال، التسويق، الإدارة التجارية، الوظائف المكتبية، خدمات البيع بالتجزئة."
  },
  {
    classNumber: 36,
    titleEn: "Financial Services",
    titleAr: "الخدمات المالية والمصرفية",
    defaultGoodsEn: "Financial transactions, banking services, insurance administration, real estate agency, investment portfolios.",
    defaultGoodsAr: "المعاملات المالية، الخدمات المصرفية، إدارة التأمين، الوساطة العقارية، المحافظ الاستثمارية."
  },
  {
    classNumber: 41,
    titleEn: "Education & Entertainment",
    titleAr: "التعليم والترفيه والرياضة",
    defaultGoodsEn: "Education, training, sporting and cultural activities, production of electronic publications, exhibitions.",
    defaultGoodsAr: "التعليم والتدريب وتدريس المهارات، الأنشطة الترفيهية والرياضية والثقافية، إصدار المنشورات الرقمية."
  },
  {
    classNumber: 42,
    titleEn: "IT & Engineering Services",
    titleAr: "خدمات تكنولوجيا المعلومات والهندسة",
    defaultGoodsEn: "Scientific and technological services, industrial analysis, design of software and hardware, web development.",
    defaultGoodsAr: "الخدمات العلمية والتكنولوجية، التحليل الصناعي، تصميم وتطوير البرمجيات وأجهزه الحاسوب، تطوير مواقع الويب."
  },
  {
    classNumber: 43,
    titleEn: "Food & Hotel Services",
    titleAr: "الضيافة والمطاعم والفنادق",
    defaultGoodsEn: "Services for providing food and drink, temporary accommodation, hotel services, restaurant franchises.",
    defaultGoodsAr: "خدمات تقديم الطعام والشراب، الإقامة المؤقتة، الخدمات الفندقية، امتيازات وإدارات المطاعم الكبرى."
  },
  {
    classNumber: 2,
    titleEn: "Paints & Varnishes",
    titleAr: "الدهانات والورنيشات والطلاءات",
    defaultGoodsEn: "Paints, varnishes, lacquers, preservatives against rust and against deterioration of wood, colorants, dyestuffs.",
    defaultGoodsAr: "الدهانات، الورنيشات، المواد المقاومة للصدأ وتلف الأخشاب، المواد التلوينية، الأصباغ."
  },
  {
    classNumber: 7,
    titleEn: "Heavy Machinery & Tools",
    titleAr: "الآلات الثقيلة والأدوات الكهربائية",
    defaultGoodsEn: "Machine tools, power-operated tools, motors and engines, agricultural machinery, generators.",
    defaultGoodsAr: "أدوات الآلات، الأدوات المشغلة بالطاقة، المحركات والماكينات، الآلات الزراعية، المولدات الكهربائية."
  },
  {
    classNumber: 14,
    titleEn: "Jewelry & Precious Metals",
    titleAr: "المجوهرات والمعادن النفيسة",
    defaultGoodsEn: "Precious metals and their alloys, jewelry, precious and semi-precious stones, horological and chronometric instruments, watches.",
    defaultGoodsAr: "المعادن النفيسة وسبائكها، المجوهرات، الأحجار الكريمة وشبه الكريمة، الساعات وأجهزة قياس الوقت."
  },
  {
    classNumber: 16,
    titleEn: "Paper & Stationery Items",
    titleAr: "الأوراق والكتب والقرطاسية",
    defaultGoodsEn: "Paper and cardboard, printed matter, bookbinding material, photographs, stationery, instructional and teaching materials.",
    defaultGoodsAr: "الورق والكرتون، المواد المطبوعة، مواد تجليد الكتب، الصور الفوتوغرافية، القرطاسية، الأدوات التعليمية والتثقيفية."
  },
  {
    classNumber: 18,
    titleEn: "Leather Goods & Bags",
    titleAr: "المصنوعات الجلدية والحقائب",
    defaultGoodsEn: "Leather and imitations of leather, animal skins, luggage and carrying bags, umbrellas, walking sticks.",
    defaultGoodsAr: "الجلود والجلود الاصطناعية، جلود الحيوانات، الحقائب وحقائب السفر، المظلات، عصي المشي."
  },
  {
    classNumber: 21,
    titleEn: "Household & Glassware",
    titleAr: "الأواني المنزلية والزجاجيات",
    defaultGoodsEn: "Household or kitchen utensils and containers, cookware and tableware, glassware, porcelain and earthenware.",
    defaultGoodsAr: "الأدوات والأواني المنزلية أو المطبخية، أوعية الطهو وأدوات المائدة، الزجاجيات، البورسلين والفخار."
  },
  {
    classNumber: 38,
    titleEn: "Telecommunications & Broadcast",
    titleAr: "خدمات الاتصالات والبث اللاسلكي",
    defaultGoodsEn: "Telecommunication services, transmission of data and digital feeds, broadcasting programs, streaming services.",
    defaultGoodsAr: "خدمات الاتصالات، نقل البيانات والأعلاف الرقمية، بث البرامج الإذاعية والتلفزيونية، خدمات البث الرقمي."
  },
  {
    classNumber: 39,
    titleEn: "Logistics & Transport Storage",
    titleAr: "الخدمات اللوجستية والنقل والتخزين",
    defaultGoodsEn: "Transport, packaging and storage of goods, travel arrangement, freight forwarding, courier services.",
    defaultGoodsAr: "خدمات النقل، تغليف وتعبئة وتخزين البضائع، تنظيم الرحلات، شحن البضائع، خدمات البريد السريع الحصرية."
  },
  {
    classNumber: 44,
    titleEn: "Medical & Aesthetic Care",
    titleAr: "الخدمات الطبية والتجميلية والعناية",
    defaultGoodsEn: "Medical services, veterinary services, hygienic and beauty care for human beings or animals, agriculture and forestry.",
    defaultGoodsAr: "الخدمات الطبية، الخدمات البيطرية، خدمات الرعاية الصحية والتجميلية للبشر أو الحيوانات، خدمات الزراعة والغابات."
  },
  {
    classNumber: 45,
    titleEn: "Legal & Security Services",
    titleAr: "الخدمات القانونية والأمنية والاجتماعية",
    defaultGoodsEn: "Legal services, security services for the physical protection of tangible property and individuals, personal and social services.",
    defaultGoodsAr: "الخدمات القانونية، الخدمات الأمنية لحماية الممتلكات المادية والأفراد، الخدمات الشخصية والاجتماعية."
  }
];

export const MOCK_CERTIFICATE_PRESETS: {[key: string]: TrademarkCertificate} = {
  iraqCell: {
    id: "preset-1",
    registryNumber: "148392",
    applicationNumber: "2026/0942",
    applicationDate: "2026-03-24",
    registrationDate: "2026-06-15",
    expiryDate: "2036-03-24",
    journalNumber: "732",
    journalPageNumber: "45",
    trademarkNameEn: "IRAQ CELLULAR SYSTEMS",
    trademarkNameAr: "العراق للأنظمة الخلوية",
    trademarkLogoUrl: "telecom",
    trademarkLogoName: "telecom_pres.png",
    trademarkType: "Composite",
    trademarkTypeAr: "مشتركة (لفظية ورسمية)",
    niceClass: 9,
    goodsDescriptionEn: "Mobile telecommunication chips, high-speed routing equipment, transmitters, operating systems and software.",
    goodsDescriptionAr: "رقاقات الاتصالات اللاسلكية للهواتف المحمولة، أجهزة التوجيه عالية السرعة، أجهزة الإرسال، برمجيات ونظم التشغيل المجمعة.",
    ownerNameEn: "AL-RAFTIDAIN TELECOM HOLDING CO.",
    ownerNameAr: "شركة الرافدين القابضة للاتصالات م.خ.",
    ownerNationalityEn: "Iraqi Registered Enterprise",
    ownerNationalityAr: "منشأة مسجلة في جمهورية العراق",
    ownerAddressEn: "Building 12, Jadriya District, Baghdad, Republic of Iraq",
    ownerAddressAr: "عمارة ١٢، حي الجادرية، بغداد، جمهورية العراق",
    ownerLegalStatusEn: "Joint Stock Company",
    ownerLegalStatusAr: "شركة مساهمة خاصة",
    registrarNameEn: "Adnan M. Al-Khafaji",
    registrarNameAr: "عدنان محمد الخفاجي",
    registrarTitleEn: "Registrar of Intellectual Property & Trademarks",
    registrarTitleAr: "مسجل الملكية الصناعية والعلامات التجارية",
    registrarSignatureOption: "stamp-only",
    enableGoldSeal: true,
    enableRepublicRibbon: true,
    enableGuillocheBg: true,
    securityHash: "IQ-TM-0942-F8392-EE4B72A"
  },
  tigrisCoffee: {
    id: "preset-2",
    registryNumber: "159403",
    applicationNumber: "2026/2205",
    applicationDate: "2026-01-10",
    registrationDate: "2026-05-19",
    expiryDate: "2036-01-10",
    journalNumber: "730",
    journalPageNumber: "128",
    trademarkNameEn: "BABYLON ROASTERS & COFFEE",
    trademarkNameAr: "محامص ومقاهي بابل",
    trademarkLogoUrl: "coffee",
    trademarkLogoName: "babylon_coffee.png",
    trademarkType: "Composite",
    trademarkTypeAr: "مشتركة (لفظية ورسمية)",
    niceClass: 43,
    goodsDescriptionEn: "Premium coffee roasting services, boutique cafe outlets providing hot beverages, pastries, and branded retail beans.",
    goodsDescriptionAr: "خدمات تحميص القهوة الفاخرة، ومنافذ المقاهي المتخصصة لتقديم المشروبات الساخنة والمخبوزات وحبوب القهوة المعبأة.",
    ownerNameEn: "ASSYRIAN HERITAGE TRADING GROUP LTD.",
    ownerNameAr: "مجموعة التراث الآشوري للتجارة المحدودة",
    ownerNationalityEn: "Iraqi National Enterprise",
    ownerNationalityAr: "شركة عراقية وطنية ذ.م.م.",
    ownerAddressEn: "Al-Karada Commercial Street, Baghdad, Iraq",
    ownerAddressAr: "شارع الكرادة التجاري، بغداد، العراق",
    ownerLegalStatusEn: "Limited Liability Company",
    ownerLegalStatusAr: "شركة ذات مسؤولية محدودة",
    registrarNameEn: "Adnan M. Al-Khafaji",
    registrarNameAr: "عدنان محمد الخفاجي",
    registrarTitleEn: "Registrar of Intellectual Property & Trademarks",
    registrarTitleAr: "مسجل الملكية الصناعية والعلامات التجارية",
    registrarSignatureOption: "wet-ink",
    enableGoldSeal: true,
    enableRepublicRibbon: true,
    enableGuillocheBg: true,
    securityHash: "IQ-TM-2205-A9403-EED372F"
  },
  mesopotamianFarms: {
    id: "preset-3",
    registryNumber: "162810",
    applicationNumber: "2026/4192",
    applicationDate: "2026-05-12",
    registrationDate: "Pending / قيد الدراسة",
    expiryDate: "Under Review / تحت التدقيق",
    journalNumber: "Pending / قيد المراجعة والتدقيق",
    journalPageNumber: "Pending",
    trademarkNameEn: "MESOPOTAMIAN ORGANICS",
    trademarkNameAr: "عضويات وادي الرافدين",
    trademarkLogoUrl: "shield",
    trademarkLogoName: "mesopotamian_logo.png",
    trademarkType: "Composite",
    trademarkTypeAr: "مشتركة (لفظية ورسمية)",
    niceClass: 29,
    goodsDescriptionEn: "Organic processed dates, cold-pressed olive oils, high-quality honey and agricultural fresh food produce.",
    goodsDescriptionAr: "منتجات التمور العضوية المصنعة، وزيوت الزيتون البكر المعصورة على البارد، والعسل الطبيعي الفاخر والمحاصيل الزراعية.",
    ownerNameEn: "MESOPOTAMIAN FARMS CO.",
    ownerNameAr: "شركة مزارع الرافدين الزراعية ذ.م.م.",
    ownerNationalityEn: "Iraqi National Agricultural Enterprise",
    ownerNationalityAr: "منشأة زراعية عراقية وطنية ذ.م.م.",
    ownerAddressEn: "Babylon Agricultural Highway, Hillah, Iraq",
    ownerAddressAr: "طريق بابل الزراعي السريع، الحلة، جمهورية العراق",
    ownerLegalStatusEn: "Limited Liability Company",
    ownerLegalStatusAr: "شركة ذات مسؤولية محدودة",
    registrarNameEn: "Adnan M. Al-Khafaji",
    registrarNameAr: "عدنان محمد الخفاجي",
    registrarTitleEn: "Registrar of Intellectual Property & Trademarks",
    registrarTitleAr: "مسجل الملكية الصناعية والعلامات التجارية",
    registrarSignatureOption: "digital-only",
    enableGoldSeal: false,
    enableRepublicRibbon: false,
    enableGuillocheBg: true,
    securityHash: "IQ-TM-4192-PENDING-EED983B",
    status: "Pending"
  }
};
