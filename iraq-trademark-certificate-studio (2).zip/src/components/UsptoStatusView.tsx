import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, Shield, CheckCircle, Calendar, User, MapPin, 
  Activity, FileText, Printer, FileDown, ExternalLink, 
  Briefcase, Globe, Building, Gavel, Clock, BookOpen, 
  ArrowLeft, Copy, HelpCircle, Check, AlertCircle, Award
} from 'lucide-react';
import { TrademarkCertificate } from '../types';
import { QRCodeSVG } from 'qrcode.react';

const IraqEmblemSVG = () => (
  <svg className="w-12 h-14 text-amber-700 shrink-0 select-none print:w-14 print:h-16" viewBox="0 0 100 120" fill="currentColor">
    {/* Eagle Head & Crown */}
    <path d="M46 15 Q48 10 50 10 Q52 10 54 15 L52 18 L48 18 Z" fill="currentColor" />
    <path d="M48 18 L52 18 L50 25 Z" fill="currentColor" opacity="0.95" />
    {/* Eagle Wings representing the majestic Eagle of Saladin */}
    <path d="M40 22 C30 25 15 45 15 80 C25 75 35 60 38 45 Z" fill="currentColor" />
    <path d="M60 22 C70 25 85 45 85 80 C75 75 65 60 62 45 Z" fill="currentColor" />
    {/* Core Shield with vertical stripes representing Flag of Iraq */}
    <path d="M38 40 C38 40 50 35 62 40 L60 75 C50 82 50 82 40 75 Z" fill="currentColor" opacity="0.9" />
    {/* Flag Stripes (Red, White, Black) */}
    <rect x="41" y="44" width="6" height="30" fill="#dc2626" />
    <rect x="47" y="43" width="6" height="32" fill="#ffffff" />
    <rect x="53" y="44" width="6" height="30" fill="#171717" />
    {/* Small stars or text on White Stripe */}
    <circle cx="50" cy="53" r="1.2" fill="#16a34a" />
    <circle cx="50" cy="59" r="1.2" fill="#16a34a" />
    <circle cx="50" cy="65" r="1.2" fill="#16a34a" />
    {/* Eagle Body claw grip */}
    <path d="M38 80 L62 80 L58 88 L42 88 Z" fill="currentColor" />
    {/* Base Ribbon representing: جمهورية العراق */}
    <path d="M20 90 Q50 85 80 90 L85 100 Q50 95 15 100 Z" fill="#15803d" />
    <text x="50" y="97" textAnchor="middle" fill="#ffffff" fontSize="6.5" fontWeight="black" className="font-sans antialiased">
      جمهورية العراق
    </text>
  </svg>
);

interface UsptoStatusViewProps {
  currentCert: TrademarkCertificate;
  onSelectCert: (cert: TrademarkCertificate) => void;
  mockPresets: Record<string, TrademarkCertificate>;
  onExit: () => void;
}

export default function UsptoStatusView({ 
  currentCert, 
  onSelectCert, 
  mockPresets,
  onExit 
}: UsptoStatusViewProps) {
  const [searchQuery, setSearchQuery] = useState<string>(currentCert.registryNumber);
  const [displayedCert, setDisplayedCert] = useState<TrademarkCertificate>(currentCert);
  const [activeTab, setActiveTab] = useState<'status' | 'documents' | 'history'>('status');
  const [searchError, setSearchError] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [viewLanguage, setViewLanguage] = useState<'ar' | 'en' | 'bilingual'>('bilingual');

  // Sync displayed cert when currentCert changes from parent (presets)
  useEffect(() => {
    setDisplayedCert(currentCert);
    setSearchQuery(currentCert.registryNumber);
  }, [currentCert]);

  const handleSearch = (queryStr: string) => {
    const trimmed = queryStr.trim();
    if (!trimmed) {
      setSearchError("يرجى إدخال رقم تسجيل صحيح أو اسم العلامة التجارية / Please enter a valid identifier.");
      return;
    }

    setIsSearching(true);
    setSearchError(null);

    setTimeout(() => {
      const lower = trimmed.toLowerCase();
      // Search presets & current
      const foundInPresets = Object.values(mockPresets).find(p => 
        p.registryNumber === trimmed ||
        p.trademarkNameEn.toLowerCase().includes(lower) ||
        p.trademarkNameAr.includes(trimmed)
      );

      setIsSearching(false);

      if (foundInPresets) {
        setDisplayedCert(foundInPresets);
      } else if (
        currentCert.registryNumber === trimmed ||
        currentCert.trademarkNameEn.toLowerCase().includes(lower) ||
        currentCert.trademarkNameAr.includes(trimmed)
      ) {
        setDisplayedCert(currentCert);
      } else {
        setSearchError(`لم يتم العثور على سجل متاح للرقم "${trimmed}" في قاعدة البيانات الوطنية / No verified record found for "${trimmed}" in this public query index.`);
      }
    }, 450);
  };

  const copyField = (text: string, fieldKey: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedKey(fieldKey);
      setTimeout(() => setCopiedKey(null), 1500);
    });
  };

  const copyVerifyLink = () => {
    const url = `https://iraqtrademarkdatabase.org/verify/${displayedCert.registryNumber}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    });
  };

  const isExpired = () => {
    if (!displayedCert.expiryDate) return false;
    try {
      const expDate = new Date(displayedCert.expiryDate);
      return expDate < new Date();
    } catch {
      return false;
    }
  };

  const getStatusBadge = () => {
    if (displayedCert.status === 'Pending' || displayedCert.expiryDate?.toLowerCase().includes('under') || displayedCert.registrationDate?.toLowerCase().includes('pending')) {
      return (
        <div className="flex items-center gap-2 px-3.5 py-1.5 bg-amber-50 border border-amber-300 text-amber-800 rounded-lg text-xs font-bold font-mono">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
          <span>
            {viewLanguage === 'ar' ? 'قيد الدراسة والبحث والمراجعة' : 
             viewLanguage === 'en' ? 'PENDING / UNDER EXAMINATION' : 
             'قيد المراجعة والبحث / PENDING (UNDER EXAMINATION)'}
          </span>
        </div>
      );
    }
    if (isExpired()) {
      return (
        <div className="flex items-center gap-2 px-3.5 py-1.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs font-bold font-mono">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
          <span>
            {viewLanguage === 'ar' ? 'منتهية الصلاحية (ملغية)' : 
             viewLanguage === 'en' ? 'EXPIRED (DEAD)' : 
             'منتهية الصلاحية / EXPIRED (DEAD)'}
          </span>
        </div>
      );
    }
    return (
      <div className="flex items-center gap-2 px-3.5 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg text-xs font-bold font-mono">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-550 animate-ping shrink-0" />
        <span>
          {viewLanguage === 'ar' ? 'مسجلة ونشطة (سارية المفعول)' : 
           viewLanguage === 'en' ? 'REGISTERED AND ACTIVE (LIVE)' : 
           'مسجلة ونشطة / REGISTERED AND ACTIVE (LIVE)'}
        </span>
      </div>
    );
  };

  const letters = displayedCert.trademarkNameEn ? displayedCert.trademarkNameEn.substring(0, 2).toUpperCase() : "IQ";

  const getLogoIcon = (url: string) => {
    if (url === 'telecom') {
      return (
        <svg className="w-16 h-16 text-emerald-700 font-bold" viewBox="0 0 100 100" fill="currentColor">
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="2.5" strokeDasharray="4 2" />
          <path d="M50 20 L50 80 M20 50 L80 50" stroke="currentColor" strokeWidth="2" />
          <circle cx="50" cy="50" r="15" fill="currentColor" opacity="0.15" />
          <path d="M35 35 Q50 20 65 35" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <path d="M25 25 Q50 5 75 25" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <circle cx="50" cy="50" r="6" fill="currentColor" />
        </svg>
      );
    }
    if (url === 'coffee') {
      return (
        <svg className="w-16 h-16 text-amber-800 font-bold" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3">
          <path d="M30 40 C30 25 70 25 70 40 C70 55 30 55 30 40 Z" fill="currentColor" fillOpacity="0.1" />
          <path d="M70 35 C78 35 78 45 70 45" strokeLinecap="round" />
          <path d="M40 65 Q50 80 60 65" strokeLinecap="round" />
          <path d="M25 65 L75 65" strokeWidth="4.5" strokeLinecap="round" />
          <path d="M44 25 Q46 14 42 9 M52 25 Q54 11 49 9 M37 25 Q39 16 35 11" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    }
    if (url === 'shield') {
      return (
        <svg className="w-16 h-16 text-slate-800" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3">
          <path d="M50 15 C65 15 80 10 80 10 L80 40 C80 65 50 85 50 85 C50 85 20 65 20 40 L20 10 C20 10 35 15 50 15 Z" fill="currentColor" fillOpacity="0.1" />
          <circle cx="50" cy="45" r="10" strokeWidth="2.5" strokeDasharray="3 1.5" />
          <text x="50" y="55" textAnchor="middle" fill="currentColor" fontSize="12" fontWeight="bold" stroke="none" className="font-mono">
            {letters}
          </text>
        </svg>
      );
    }
    if (url && url.startsWith('data:image')) {
      return (
        <img 
          src={url} 
          alt="Trademark Logo" 
          className="max-w-full max-h-full object-contain rounded" 
          referrerPolicy="no-referrer" 
        />
      );
    }
    return (
      <div className="w-16 h-16 border-2 border-amber-600 rounded-full flex items-center justify-center bg-amber-500/5 shadow-inner relative overflow-hidden">
        <div className="absolute inset-1 border border-amber-500/40 border-dashed rounded-full" />
        <span className="text-lg font-bold font-mono text-amber-700 relative z-10">{letters}</span>
      </div>
    );
  };

  return (
    <div className="bg-white border border-slate-250 rounded-2xl shadow-xl p-4 sm:p-6 text-slate-800 flex flex-col font-sans space-y-6">
      
      {/* Prime Official Header (Bilingual Iraq Ministry layout) */}
      <div className="flex flex-col md:flex-row items-stretch justify-between gap-4 pb-5 border-b border-slate-200">
        <div className="flex items-center gap-4">
          <div className="shrink-0">
            <IraqEmblemSVG />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10.5px] font-bold text-amber-850 uppercase tracking-wide font-sans">
                جمهورية العراق • وزارة الصناعة والمعادن
              </span>
              <span className="text-[9.5px] bg-[#0284c7]/10 text-[#0284c7] font-semibold px-2 py-0.5 rounded border border-[#0284c7]/20">
                COSQC • الجهاز المركزي للتقييس والسيطرة النوعية
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-sans tracking-tight flex items-center gap-2 mt-1">
              iraqtrademarkdatabase.org
            </h2>
            <p className="text-xs text-slate-500 tracking-normal leading-relaxed font-sans">
              البوابة الوطنية الموحدة لتسجيل وتدقيق البيانات وسجل العلامات التجارية الإلكتروني
              <span className="text-[11px] text-slate-400 block font-mono">Official State Intellectual Property e-Portal (.gov.iq systems proxy)</span>
            </p>
          </div>
        </div>

        {/* Action Controls & Language Selector */}
        <div className="flex flex-[0.8] md:flex-none flex-col sm:flex-row md:flex-col items-end gap-3 justify-center shrink-0 self-start md:self-center">
          
          {/* Interactive view language switcher */}
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200/80 no-print">
            <button 
              type="button" 
              onClick={() => setViewLanguage('bilingual')} 
              className={`px-3 py-1 text-[10.5px] font-bold rounded transition-all duration-150 ${viewLanguage === 'bilingual' ? 'bg-amber-600 text-white shadow-sm font-extrabold' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Dual / ثنائي
            </button>
            <button 
              type="button" 
              onClick={() => setViewLanguage('ar')} 
              className={`px-3 py-1 text-[10.5px] font-bold rounded transition-all duration-150 ${viewLanguage === 'ar' ? 'bg-amber-600 text-white shadow-sm font-extrabold' : 'text-slate-500 hover:text-slate-800'}`}
            >
              العربية
            </button>
            <button 
              type="button" 
              onClick={() => setViewLanguage('en')} 
              className={`px-3 py-1 text-[10.5px] font-bold rounded transition-all duration-150 ${viewLanguage === 'en' ? 'bg-amber-600 text-white shadow-sm font-extrabold' : 'text-slate-500 hover:text-slate-800'}`}
            >
              English
            </button>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button 
              onClick={copyVerifyLink}
              className="flex-1 sm:flex-none px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 rounded-xl flex items-center justify-center gap-1.5 transition whitespace-nowrap"
            >
              <Copy className="w-4 h-4 text-slate-500" />
              <span>{copiedLink ? 'تم نسخ الرابط!' : 'نسخ رابط التحقق / Copy Link'}</span>
            </button>

            <button 
              onClick={() => window.print()}
              className="flex-1 sm:flex-none px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition shadow-sm whitespace-nowrap"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة السجل / Print Docket</span>
            </button>
          </div>

        </div>
      </div>

      {/* Online Search Panel (Minimal, pure official registry style) */}
      <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-3 shadow-inner">
        <div className="flex justify-between items-center flex-wrap gap-2">
          <span className="text-xs font-bold font-mono tracking-wide text-slate-700 uppercase flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-slate-500" />
            {viewLanguage === 'ar' ? 'البحث عن العلامات في سجل الملكية الوطنية الإلكتروني' : 
             viewLanguage === 'en' ? 'Search Verified Intellectual Property & Trademarks' : 
             'البحث في سجل العلامات التجارية الوطني / Search Registered IP Database'}
          </span>
          <span className="text-[10px] text-emerald-700 font-mono tracking-tight bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
            {viewLanguage === 'en' ? '● Registry Sync Connected' : '● متصل بسجل الوزارة الموحد / Registry Sync Active'}
          </span>
        </div>
        
        <div className="flex gap-2.5">
          <div className="relative flex-1">
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch(searchQuery);
                }
              }}
              placeholder={
                viewLanguage === 'ar' ? "أدخل رقم العلامة المتسلسل (مثال: 148392) أو كلمة البحث الرئيسية..." :
                viewLanguage === 'en' ? "Enter registration serial (e.g. 148392) or brand trademark keyword..." :
                "أدخل رقم العلامة المتسلسل (مثال: 148392) أو كلمة البحث الرئيسية / Enter registration serial or keyword..."
              }
              className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-amber-500 font-mono placeholder:text-slate-400"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-3.5" />
          </div>
          <button 
            onClick={() => handleSearch(searchQuery)}
            disabled={isSearching}
            className="px-6 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:bg-amber-600/50 text-white font-bold text-xs rounded-lg transition duration-150 flex items-center gap-2 shrink-0 select-none shadow"
          >
            {isSearching ? <Clock className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>{viewLanguage === 'ar' ? 'استعلام' : viewLanguage === 'en' ? 'Query' : 'استعلام / Search'}</span>
          </button>
        </div>

        {searchError && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
            <span className="font-mono leading-relaxed">{searchError}</span>
          </div>
        )}
      </div>

      {/* Official Registry Counters & Live Statistics (No-Print) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 no-print text-xs">
        <div className="bg-emerald-50/40 border border-emerald-100 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-emerald-800 font-bold font-sans">
              العلامات الحية المسجلة / Active Registered Marks
            </p>
            <h4 className="text-lg sm:text-xl font-bold font-mono text-emerald-700 mt-1 flex items-baseline gap-1">
              <span>52,481</span>
              <span className="text-[9.5px] font-normal text-slate-500 lowercase">active live</span>
            </h4>
          </div>
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
        </div>
        
        <div className="bg-amber-50/40 border border-amber-100 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-amber-800 font-bold font-sans">
              الطلبات قيد الفحص والدراسة / Pending Applications
            </p>
            <h4 className="text-lg sm:text-xl font-bold font-mono text-amber-700 mt-1 flex items-baseline gap-1">
              <span>8,412</span>
              <span className="text-[9.5px] font-normal text-slate-500 lowercase">examination desk</span>
            </h4>
          </div>
          <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
        </div>

        <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-slate-500 font-bold font-sans">
              البوابات الحكومية المتصلة / Active Gov Proxy
            </p>
            <h4 className="text-[11.5px] sm:text-xs font-bold font-mono text-slate-700 mt-1.5 uppercase">
              MIM-IQ • COSQC-Active <span className="text-[9px] text-[#0284c7] bg-[#0284c7]/5 px-1 py-0.2 border border-[#0284c7]/15 rounded uppercase">linked</span>
            </h4>
          </div>
          <Globe className="w-4 h-4 text-slate-400 shrink-0" />
        </div>
      </div>

      {/* Main TSDR Government Docket Sheet Layout */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col">
        
        {/* Upper metadata status belt */}
        <div className="bg-slate-50/80 p-5 px-6 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-lg sm:text-xl font-bold font-mono tracking-tight text-slate-950 uppercase select-all">
                MARK: {displayedCert.trademarkNameEn}
              </span>
              <span className="text-base sm:text-lg font-bold font-amiri text-amber-850 px-2">
                [{displayedCert.trademarkNameAr}]
              </span>
            </div>
            <div className="text-xs text-slate-500 font-mono flex flex-wrap items-center gap-3">
              <span>رقم التسجيل / Serial No: <strong className="text-slate-900 select-all">{displayedCert.registryNumber}</strong></span>
              <span className="text-slate-300">•</span>
              <span>الفئة / Class: <strong className="text-slate-900">Class {displayedCert.niceClass}</strong></span>
            </div>
          </div>
          
          <div className="self-end sm:self-center shrink-0">
            {getStatusBadge()}
          </div>
        </div>

        {/* Tab Selector layout (clean white look) */}
        <div className="bg-slate-50 border-b border-slate-200 px-3 flex items-center gap-1">
          <button 
            type="button"
            onClick={() => setActiveTab('status')}
            className={`px-4 py-3.5 border-b-2 text-xs font-bold font-mono tracking-wider transition flex items-center gap-1.5 ${activeTab === 'status' ? 'border-amber-600 text-amber-700 bg-white' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>
              {viewLanguage === 'ar' ? 'حالة السجل الفيدرالي' : 
               viewLanguage === 'en' ? 'DOCKET STATUS' : 
               'حالة السجل / STATUS'}
            </span>
          </button>
          
          <button 
            type="button"
            onClick={() => setActiveTab('documents')}
            className={`px-4 py-3.5 border-b-2 text-xs font-bold font-mono tracking-wider transition flex items-center gap-1.5 ${activeTab === 'documents' ? 'border-amber-600 text-amber-700 bg-white' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>
              {viewLanguage === 'ar' ? 'الوثائق والأرشفة' : 
               viewLanguage === 'en' ? 'FILE DOCUMENTS' : 
               'الوثائق المرفقة / DOCUMENTS'}
            </span>
          </button>

          <button 
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-4 py-3.5 border-b-2 text-xs font-bold font-mono tracking-wider transition flex items-center gap-1.5 ${activeTab === 'history' ? 'border-amber-600 text-amber-700 bg-white' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>
              {viewLanguage === 'ar' ? 'مراحل الطلب الفنية' : 
               viewLanguage === 'en' ? 'PROSECUTION TIMELINE' : 
               'مراحل الطلب / TIMELINE'}
            </span>
          </button>
        </div>

        {/* Tab display */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            
            {activeTab === 'status' && (
              <motion.div 
                key="tab-status"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-6 text-xs text-slate-700 font-mono"
              >
                {/* Visual Stamp Certificate & Logo Combo */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
                  
                  {/* Trademark logo display quadrant */}
                  <div className="md:col-span-4 bg-slate-50 border border-slate-200 p-5 rounded-xl flex flex-col justify-between items-center gap-4 text-center">
                    <div className="space-y-1">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block font-mono">
                        نموذج العلامة المودعة
                      </span>
                      <p className="text-[9px] text-slate-400">Trademark Representation</p>
                    </div>

                    <div className="w-32 h-32 bg-white border border-slate-250 rounded-xl p-4 flex items-center justify-center relative shadow-sm">
                      {getLogoIcon(displayedCert.trademarkLogoUrl)}
                    </div>
                    
                    <div className="space-y-1">
                      <span className="text-[10px] tracking-tight truncate block max-w-[140px] text-slate-650 font-bold font-mono">
                        {displayedCert.trademarkLogoName || "logo_standard.png"}
                      </span>
                      <span className="text-[9px] text-slate-500 block">Mark Type: {displayedCert.trademarkType} ({displayedCert.trademarkTypeAr})</span>
                    </div>
                  </div>

                  {/* Standard Detailed status fields */}
                  <div className="md:col-span-8 bg-slate-50 border border-slate-200 p-5 rounded-xl space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                      <Shield className="w-4 h-4 text-amber-700" />
                      <span className="font-bold text-slate-800 uppercase text-xs tracking-wider font-sans">
                        بيانات شهادة العلامة الرسمية / Certificate Details
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      <div className="space-y-1 p-2 bg-white border border-slate-200 rounded">
                        <span className="text-slate-400 text-[10px] uppercase font-bold">اسم العلامة (لاتيني) • English Word Mark</span>
                        <p className="text-slate-900 font-black select-all text-xs">{displayedCert.trademarkNameEn}</p>
                      </div>

                      <div className="space-y-1 p-2 bg-white border border-slate-200 rounded">
                        <span className="text-slate-400 text-[10px] uppercase font-bold">اسم العلامة (عربي) • Arabic Word Mark</span>
                        <p className="text-amber-800 font-bold font-amiri text-sm leading-none pt-1 select-all">{displayedCert.trademarkNameAr}</p>
                      </div>

                      <div className="space-y-1 p-2 bg-white border border-slate-200 rounded">
                        <span className="text-slate-400 text-[10px] uppercase font-bold">رقم التسجيل • Registration Identifier</span>
                        <div className="flex items-center justify-between">
                          <p className="text-slate-900 font-bold select-all">{displayedCert.registryNumber}</p>
                          <button onClick={() => copyField(displayedCert.registryNumber, 'reg_num')} className="text-slate-400 hover:text-slate-600">
                            {copiedKey === 'reg_num' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-1 p-2 bg-white border border-slate-200 rounded">
                        <span className="text-slate-400 text-[10px] uppercase font-bold">رقم الطلب الفني • Case Submission Serial</span>
                        <div className="flex items-center justify-between">
                          <p className="text-slate-900 font-bold select-all">{displayedCert.applicationNumber}</p>
                          <button onClick={() => copyField(displayedCert.applicationNumber, 'app_num')} className="text-slate-400 hover:text-slate-600">
                            {copiedKey === 'app_num' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-1 p-2 bg-white border border-slate-200 rounded">
                        <span className="text-slate-400 text-[10px] uppercase font-bold">سجل النشر • Gazetted Journal Archive</span>
                        <p className="text-slate-900">سجل العلامات الوطني العام (National Principal Register)</p>
                      </div>

                      <div className="space-y-1 p-2 bg-white border border-slate-200 rounded">
                        <span className="text-slate-400 text-[10px] uppercase font-bold">طبيعة العلامة • Category Classification</span>
                        <p className="text-slate-900">{displayedCert.trademarkType} / {displayedCert.trademarkTypeAr}</p>
                      </div>

                    </div>

                    <div className="p-3 bg-amber-50/50 border border-amber-200 rounded text-[11px] leading-relaxed text-amber-900">
                      <strong>ملاحظة قانونية / LEGAL NOTIFICATION:</strong> تم إصدار وقيد هذه العلامة التجارية رسمياً بموجب قانون العلامات والبيانات التجارية رقم 21 لسنة 1957 وتعديلاته في جمهورية العراق. الرقم الرمزي لسلامة الوثيقة: <span className="font-mono text-xs font-bold leading-none break-all text-slate-800">{displayedCert.securityHash}</span>
                    </div>
                  </div>

                </div>

                {/* Nice class details table */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                    <Briefcase className="w-4 h-4 text-amber-700" />
                    <span className="font-bold text-slate-800 uppercase text-xs tracking-wider font-sans">
                      تصنيف السلع والخدمات الدولي / Goods and Services (International Nice Class)
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px] leading-normal font-mono">
                      <thead>
                        <tr className="border-b border-slate-200 text-slate-500 text-left">
                          <th className="py-2.5 font-bold uppercase tracking-wider w-16 text-slate-800">Class</th>
                          <th className="py-2.5 font-bold uppercase tracking-wider w-1/2 text-slate-800 font-sans">بيان المنتجات المعتمد / Goods & Services Description</th>
                          <th className="py-2.5 font-bold uppercase tracking-wider text-right text-slate-800 font-sans">الحالة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        <tr>
                          <td className="py-3 font-semibold text-slate-950 align-top font-bold text-sm">
                            {displayedCert.niceClass.toString().padStart(3, '0')}
                          </td>
                          <td className="py-3 space-y-2 pr-4 text-slate-800">
                            <div>
                              <span className="text-[10px] text-slate-400 uppercase block font-bold font-mono">English Definition</span>
                              <p className="text-slate-800 leading-normal font-semibold font-sans">{displayedCert.goodsDescriptionEn}</p>
                            </div>
                            <div className="bg-white p-3 rounded border border-slate-200">
                              <span className="text-[10px] text-amber-800 uppercase block font-bold font-sans">الوصف التفصيلي باللغة العربية</span>
                              <p className="text-slate-800 leading-relaxed font-amiri text-[13px] pt-1" dir="rtl">{displayedCert.goodsDescriptionAr}</p>
                            </div>
                          </td>
                          <td className="py-3 text-right align-top">
                            <span className="text-[9px] font-bold bg-emerald-100 border border-emerald-200 text-emerald-800 px-2 py-0.5 rounded uppercase">
                              نشطة ومقبولة / Live
                            </span>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Proprietor and key execution timelines */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Owner specs block */}
                  <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                      <User className="w-4 h-4 text-amber-700" />
                      <span className="font-bold text-slate-850 uppercase text-xs tracking-wider font-sans">
                        بيانات مالك العلامة / Proprietor Information
                      </span>
                    </div>

                    <div className="space-y-3 font-sans">
                      <div>
                        <span className="text-[9px] text-slate-450 uppercase font-bold block font-mono">الاسم الكامل / Proprietor Legal Name</span>
                        <p className="text-slate-900 font-bold font-serif text-sm select-all">{displayedCert.ownerNameEn}</p>
                        <p className="text-amber-900 font-amiri text-[13px] mt-0.5" dir="rtl">{displayedCert.ownerNameAr}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <span className="text-[9px] text-slate-450 uppercase font-bold block font-mono">الكيان القانوني / Legal Entity</span>
                          <p className="text-slate-800 text-xs font-semibold">{displayedCert.ownerLegalStatusEn}</p>
                          <p className="text-[10px] text-slate-500 font-amiri" dir="rtl">{displayedCert.ownerLegalStatusAr}</p>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-450 uppercase font-bold block font-mono">الجنسية / Nationality</span>
                          <p className="text-slate-800 text-xs font-semibold">{displayedCert.ownerNationalityEn}</p>
                        </div>
                      </div>

                      <div>
                        <span className="text-[9px] text-slate-450 uppercase font-bold block font-mono">العنوان المقيد / Corporate Address</span>
                        <p className="text-slate-700 text-xs leading-normal font-sans select-all">{displayedCert.ownerAddressEn}</p>
                        <p className="text-slate-500 font-amiri text-xs mt-0.5" dir="rtl">{displayedCert.ownerAddressAr}</p>
                      </div>
                    </div>
                  </div>

                  {/* High fidelity timeline milestones */}
                  <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                      <Calendar className="w-4 h-4 text-emerald-700" />
                      <span className="font-bold text-slate-800 uppercase text-xs tracking-wider font-sans">
                        التواريخ الزمنية للعلامة / Chronological Schedule
                      </span>
                    </div>

                    <div className="space-y-3 font-sans">
                      <div className="flex justify-between items-center py-2 border-b border-slate-200">
                        <span className="text-slate-500 text-xs">تاريخ إيداع الطلب / Application Date:</span>
                        <span className="text-slate-900 font-mono font-bold select-all">{displayedCert.applicationDate}</span>
                      </div>
                      
                      <div className="flex justify-between items-center py-2 border-b border-slate-200">
                        <span className="text-slate-500 text-xs">تاريخ النشر بالجريدة / Gazette Publication:</span>
                        <span className="text-slate-900 font-mono font-bold select-all">{displayedCert.registrationDate}</span>
                      </div>

                      <div className="flex justify-between items-center py-2 border-b border-slate-200">
                        <span className="text-slate-500 text-xs">تاريخ التسجيل الرسمي / Registration Date:</span>
                        <span className="text-slate-900 font-mono font-bold select-all">{displayedCert.registrationDate}</span>
                      </div>

                      <div className="flex justify-between items-center py-2">
                        <span className="text-slate-500 text-xs">نهاية الصلاحية القانونية / Renewal Deadline:</span>
                        <span className={`font-mono font-bold select-all ${isExpired() ? 'text-rose-600' : 'text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200'}`}>
                          {displayedCert.expiryDate}
                        </span>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Validation stamping column block representation */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1 font-sans">
                    <span className="font-bold text-slate-900 text-xs uppercase flex items-center gap-1.5 font-mono">
                      <Gavel className="w-4 h-4 text-amber-700" />
                      حجية الختم الإلكتروني والتوثيق / Authentication Registry Seal
                    </span>
                    <p className="text-slate-600 text-xs leading-normal">
                      تم تدقيق هذه البيانات من قبل مسجل العلامات التجارية <strong>{displayedCert.registrarNameEn} / {displayedCert.registrarNameAr}</strong> وهو ممهور بالختم الرقمي للمكتب الصناعي بوزارة الصناعة والمعادن العراقية.
                    </p>
                  </div>
                  <div className="flex items-center justify-end gap-3 self-center">
                    <div className="p-2 bg-white border border-slate-250 rounded shadow-inner">
                      <QRCodeSVG value={`https://iraqtrademarkdatabase.org/verify/${displayedCert.registryNumber}`} size={50} />
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono space-y-0.5">
                      <p className="font-bold text-amber-800 uppercase">قاعدة البيانات الرسمية للوزارة / ONLINE SYSTEM</p>
                      <p>HINT: {displayedCert.securityHash.substring(0, 16)}...</p>
                      <p>VERIFICATION: SECURE-SSL // PORTAL-MIM</p>
                    </div>
                  </div>
                </div>

              </motion.div>
            )}

            {activeTab === 'documents' && (
              <motion.div 
                key="tab-documents"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3 text-xs leading-normal">
                  <BookOpen className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                  <div className="font-sans">
                    <p className="font-bold text-slate-900 uppercase tracking-wide">الوقوعات والوثائق المؤرشفة / Document Repositories</p>
                    <p className="text-slate-550 mt-1">
                      تفاصيل الشهادات والقرارات الوزارية المقترنة بطلب العلامة المتاح أونلاين. تشتمل على نسخة شهادة تسجيل العلامة التجارية الرسمية الملونة ثنائية اللغة لجمهورية العراق.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-500/10 border border-amber-300 rounded-lg flex items-center justify-center text-amber-700">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="text-xs font-mono">
                      <h4 className="font-bold text-slate-900">شهادة تسجيل العلامة التجارية باللغتين العربية والانجليزية ({displayedCert.registryNumber})</h4>
                      <p className="text-slate-500 text-[10px] mt-0.5">Bilingual Certified Iraqi Trademark Registration Certificate (Print Replica)</p>
                    </div>
                  </div>

                  <button 
                    onClick={onExit}
                    className="w-full sm:w-auto px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span className="font-sans">عرض الشهادة وطباعتها / Render Certificate</span>
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'history' && (
              <motion.div 
                key="tab-history"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-4"
              >
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3 text-xs leading-normal">
                  <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                  <div className="font-sans">
                    <p className="font-bold text-slate-900 uppercase tracking-wide">المراحل والقيود التاريخية للعلامة / Prosecution timeline</p>
                    <p className="text-slate-550 mt-1">
                      تمثل هذه الأرصدة كافة الإجراءات والخطوات الإدارية التي مرت بها العلامة منذ تقديم طلب الملحق الأولي ولغاية سريان مفعول الحماية الوطنية الكاملة بعمر عشر سنوات.
                    </p>
                  </div>
                </div>

                {/* Formal Sand Timeline interface */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 font-mono text-xs text-slate-700 relative space-y-6">
                  
                  {/* central lane */}
                  <div className="absolute top-8 bottom-8 left-6 w-0.5 bg-slate-200" />
                  
                  {displayedCert.status === 'Pending' || displayedCert.expiryDate?.toLowerCase().includes('under') || displayedCert.registrationDate?.toLowerCase().includes('pending') ? (
                    <>
                      {/* Milestone 1: Pending active desk review */}
                      <div className="relative pl-10">
                        <div className="absolute left-4 w-4 h-4 rounded-full bg-amber-50 border-2 border-amber-500 flex items-center justify-center transform -translate-x-1.5 animate-pulse">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        </div>
                        <div className="space-y-1 font-sans">
                          <p className="font-bold uppercase text-[10px] tracking-wider text-amber-700">
                            {viewLanguage === 'ar' ? 'العلامة قيد الفحص والدراسة والمراجعة المستندية' : 
                             viewLanguage === 'en' ? 'PENDING ACTIVE REGISTRY EXAMINATION' : 
                             'الملف قيد الدراسة الفنية والقانونية / PENDING ACTIVE EXAMINATION'}
                          </p>
                          <p className="text-slate-950 font-mono text-xs font-bold">STATUS: UNDER EXAMINATION / قيد الفحص والدراسة</p>
                          <p className="text-slate-550 text-[11px] leading-relaxed">
                            {viewLanguage === 'ar' ? 'الملف الآن لدى جدول مسجل العلامات التجارية لفيف الفحص الفني للتحقق من عدم التشابه والأهلية العامة بموجب قانون العلامات رقم 21.' : 
                             viewLanguage === 'en' ? 'The application is currently with the Registry Examiner to verify eligibility, classification standards, and distinctiveness requirements.' : 
                             'الملف يخضع حالياً لتدقيق تصنيفي ومستندي فني من قبل مسجل العلامات للتحقق من عدم التشابه والتعارض مع علامات أخرى مقيدة.'}
                          </p>
                        </div>
                      </div>

                      {/* Milestone 2: Application lodging */}
                      <div className="relative pl-10">
                        <div className="absolute left-4 w-4 h-4 rounded-full bg-slate-100 border-2 border-slate-400 flex items-center justify-center transform -translate-x-1.5">
                          <Check className="w-2.5 h-2.5 text-slate-600" />
                        </div>
                        <div className="space-y-1 font-sans">
                          <p className="font-bold uppercase text-[10px] tracking-wider text-slate-700">
                            {viewLanguage === 'ar' ? 'إيداع وقبول طلب العلامة الأولي' : 
                             viewLanguage === 'en' ? 'INITIAL APPLICATION LODGED & RECORDED' : 
                             'تقديم وإيداع طلب العلامة الأولي / INITIAL APPLICATION FILED'}
                          </p>
                          <p className="text-slate-950 font-mono text-xs font-bold">{displayedCert.applicationDate}</p>
                          <p className="text-slate-550 text-[11px] leading-relaxed">
                            {viewLanguage === 'ar' ? `تم استلام مستندات العلامة رسمياً بقيد الطلب الفني المقيد برقم: ${displayedCert.applicationNumber}.` : 
                             viewLanguage === 'en' ? `The petition for brand trademark registration was officially filed and assigned serial No: ${displayedCert.applicationNumber}.` : 
                             `تم استلام أوراق وقيد الطلب الأولي رسمياً بوزارة الصناعة والمعادن وسجلت برقم الطلب الفني المتسلسل ${displayedCert.applicationNumber}.`}
                          </p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {/* 1 */}
                      <div className="relative pl-10">
                        <div className="absolute left-4 w-4 h-4 rounded-full bg-amber-50 border-2 border-amber-600 flex items-center justify-center transform -translate-x-1.5">
                          <Clock className="w-2 h-2 text-amber-700" />
                        </div>
                        <div className="space-y-1 font-sans">
                          <p className="font-bold uppercase text-[10px] tracking-wider text-amber-800">
                            {viewLanguage === 'ar' ? 'نهاية مسند الحماية القانونية الحالية (التجديد)' : 
                             viewLanguage === 'en' ? 'STATUTORY REGISTRATION EXPIRE / RENEWAL DEADLINE' : 
                             'نهاية مدة الحماية القانونية الحالية / Renewal Deadline'}
                          </p>
                          <p className="text-slate-950 font-mono text-xs font-bold">{displayedCert.expiryDate}</p>
                          <p className="text-slate-550 text-[11px]">
                            {viewLanguage === 'ar' ? 'يتعين تقديم طلب التجديد للحماية القانونية قبل انقضاء وتلاشي مدة سريان العلامة البالغة عشر سنوات لحماية الحقوق الاستئثارية.' : 
                             viewLanguage === 'en' ? 'The trademark protection requires a renewal petition to be filed on or before this date to maintain active enforcement rights.' : 
                             'يتعين تقديم طلب التمديد والتجديد قبل انقضاء وتلاشي العلامة لحفظ الحقوق الاستئثارية المسجلة.'}
                          </p>
                        </div>
                      </div>

                      {/* 2 */}
                      <div className="relative pl-10">
                        <div className="absolute left-4 w-4 h-4 rounded-full bg-emerald-50 border-2 border-emerald-600 flex items-center justify-center transform -translate-x-1.5">
                          <Check className="w-2 h-2 text-emerald-700" />
                        </div>
                        <div className="space-y-1 font-sans">
                          <p className="font-bold uppercase text-[10px] tracking-wider text-emerald-700">
                            {viewLanguage === 'ar' ? 'إصدار وقيد شهادة الحماية الرسمية للعلامة' : 
                             viewLanguage === 'en' ? 'OFFICIAL TRADEMARK REGISTRATION CERTIFICATE ISSUED' : 
                             'إصدار شهادة العلامة الرسمية / Trade Mark Certificate Issued'}
                          </p>
                          <p className="text-slate-950 font-mono text-xs font-bold">{displayedCert.registrationDate}</p>
                          <p className="text-slate-550 text-[11px]">
                            {viewLanguage === 'ar' ? `تم قيد العلامة رسمياً وتسليم شهادة التسجيل المعتمدة ثنائية اللغة بموجب القيد الحكومي رقم ${displayedCert.registryNumber}.` : 
                             viewLanguage === 'en' ? `The certified original registration was processed and issued under state ledger number ${displayedCert.registryNumber}.` : 
                             `تم تسليم وقيد الشهادة الرسمية للعلامة بالصفحة المخصصة محلياً برقم قيد ${displayedCert.registryNumber}.`}
                          </p>
                        </div>
                      </div>

                      {/* 3 */}
                      <div className="relative pl-10">
                        <div className="absolute left-4 w-4 h-4 rounded-full bg-slate-100 border-2 border-slate-400 flex items-center justify-center transform -translate-x-1.5">
                          <Globe className="w-2 h-2 text-slate-600" />
                        </div>
                        <div className="space-y-1 font-sans">
                          <p className="font-bold uppercase text-[10px] tracking-wider text-slate-700">
                            {viewLanguage === 'ar' ? 'الاعلان والنشر في جريدة الوقائع والعلامات الرسمية' : 
                             viewLanguage === 'en' ? 'OFFICIALLY REGISTERED GAZETTE PUBLICATION' : 
                             'الجريدة الرسمية للعلامات وعرض الاعتراض / Published in Gazette Journal'}
                          </p>
                          <p className="text-slate-950 font-mono text-xs font-bold">{displayedCert.registrationDate}</p>
                          <p className="text-slate-550 text-[11px]">
                            {viewLanguage === 'ar' ? `نشرت العلامة رسمياً بجريدة العلامات التجارية للوزارة بغرض إتاحة الاعتراض القانوني للغير (العدد: ${displayedCert.journalNumber}، الصفحة: ${displayedCert.journalPageNumber}).` : 
                             viewLanguage === 'en' ? `The word/device mark was gazetted in the Ministry's Trademark Journal Vol: ${displayedCert.journalNumber}, Page: ${displayedCert.journalPageNumber} for public notice and opposition.` : 
                             `نشرت العلامة في جريدة العلامات التجارية العراقية الرسمية المعتمدة (العدد: ${displayedCert.journalNumber}، الصفحة: ${displayedCert.journalPageNumber}) لإتاحة الاعتراض للغير.`}
                          </p>
                        </div>
                      </div>

                      {/* 4 */}
                      <div className="relative pl-10">
                        <div className="absolute left-4 w-4 h-4 rounded-full bg-slate-100 border-2 border-slate-400 flex items-center justify-center transform -translate-x-1.5">
                          <FileText className="w-2 h-2 text-slate-600" />
                        </div>
                        <div className="space-y-1 font-sans">
                          <p className="font-bold uppercase text-[10px] tracking-wider text-slate-700">
                            {viewLanguage === 'ar' ? 'قبول وفحص الطلب الأولي وتصنيف السلع' : 
                             viewLanguage === 'en' ? 'INITIAL CASE RECORDATION AND FEES PROCESSED' : 
                             'قبول وفحص الطلب الأولي / Initial Application Accepted'}
                          </p>
                          <p className="text-slate-950 font-mono text-xs font-bold">{displayedCert.applicationDate}</p>
                          <p className="text-slate-550 text-[11px]">
                            {viewLanguage === 'ar' ? `تم استلام وقبول الملف الأولي للمطالبة وتسجيل الرقم المستندي برقم: ${displayedCert.applicationNumber}.` : 
                             viewLanguage === 'en' ? `The initial case registration petition was processed and logged in the state repository with reference serial No: ${displayedCert.applicationNumber}.` : 
                             `تم إيداع الطلب رسمياً برقم الطلب المستندي المقيد برقم ${displayedCert.applicationNumber}.`}
                          </p>
                        </div>
                      </div>
                    </>
                  )}

                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

      </div>

    </div>
  );
}
