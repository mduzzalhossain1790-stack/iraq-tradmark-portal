import React, { useState, useEffect, useRef } from 'react';
import { 
  Award, 
  Shield, 
  Printer, 
  CheckCircle, 
  Smartphone, 
  RefreshCw, 
  Edit, 
  Upload, 
  Globe, 
  Share2, 
  Info, 
  FileText, 
  ExternalLink, 
  Sparkles,
  Download,
  AlertCircle,
  Search,
  Database,
  Check,
  Copy,
  Save
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  TrademarkCertificate, 
  NICE_CLASSES, 
  MOCK_CERTIFICATE_PRESETS 
} from './types';
import UsptoStatusView from './components/UsptoStatusView';

// Safe UTF-8 Base64 compression/decompression for URL distribution
function getCompressedUrl(cert: TrademarkCertificate): string {
  try {
    const data = {
      r: cert.registryNumber,
      a: cert.applicationNumber,
      ad: cert.applicationDate,
      rd: cert.registrationDate,
      ed: cert.expiryDate,
      jn: cert.journalNumber,
      jp: cert.journalPageNumber,
      ne: cert.trademarkNameEn,
      na: cert.trademarkNameAr,
      lo: cert.trademarkLogoUrl,
      ty: cert.trademarkType,
      c: cert.niceClass,
      oe: cert.ownerNameEn,
      oa: cert.ownerNameAr,
      de: cert.goodsDescriptionEn,
      da: cert.goodsDescriptionAr,
      le: cert.ownerLegalStatusEn,
      la: cert.ownerLegalStatusAr,
      h: cert.securityHash
    };
    const json = JSON.stringify(data);
    const utf8Bytes = new TextEncoder().encode(json);
    let binary = "";
    const len = utf8Bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(utf8Bytes[i]);
    }
    const b64 = btoa(binary);
    
    // Convert to URL-safe format to prevent query parameter parser breaks
    const urlSafeB64 = b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    
    const url = new URL(window.location.origin + window.location.pathname);
    url.searchParams.set('v', urlSafeB64);
    return url.toString();
  } catch (err) {
    console.error("Compression failed:", err);
    return window.location.origin;
  }
}

function decompressUrl(b64: string): Partial<TrademarkCertificate> | null {
  try {
    if (!b64 || typeof b64 !== 'string') return null;
    
    let targetB64 = b64.trim();
    
    // If it looks like a URL, extract the query parameter 'v' from it
    if (targetB64.includes('http://') || targetB64.includes('https://') || targetB64.includes('/?') || targetB64.includes('?v=')) {
      try {
        const urlObj = new URL(targetB64.startsWith('http') ? targetB64 : 'http://domain.placeholder' + targetB64);
        const v = urlObj.searchParams.get('v');
        if (v) {
          targetB64 = v;
        }
      } catch (e) {
        // Fallback match using regex
        const match = targetB64.match(/[?&]v=([^&]+)/);
        if (match && match[1]) {
          targetB64 = match[1];
        }
      }
    }

    const tryDecodeString = (rawB64: string): string | null => {
      try {
        if (!rawB64 || rawB64.length < 4) return null;
        
        // 1. Convert URL-safe base64 back to normal base64
        let base64 = rawB64.replace(/-/g, '+').replace(/_/g, '/');
        
        // 2. Remove white spaces and restore standard/missing padding
        base64 = base64.trim().replace(/\s/g, '');
        while (base64.length % 4 !== 0) {
          base64 += '=';
        }
        
        // 3. atob to binary string
        const binaryString = atob(base64);
        
        // 4. Convert binary string to Uint8Array safely
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          const code = binaryString.charCodeAt(i);
          bytes[i] = code > 255 ? (code & 0xFF) : code;
        }
        
        // 5. Decode with reliable TextDecoder (supports Arabic and multi-byte characters)
        const decoded = new TextDecoder().decode(bytes);
        const trimmed = decoded.trim();
        if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
          const parsed = JSON.parse(trimmed);
          // Check that it's our schema of trademark certificate to prevent general JSON collisions
          if (parsed && typeof parsed === 'object' && ('r' in parsed || 'na' in parsed || 'ne' in parsed)) {
            return trimmed;
          }
        }
        return null;
      } catch (e) {
        return null;
      }
    };

    let json: string | null = null;
    
    // Attempt 1: Raw b64 (as URL-safe or standard)
    json = tryDecodeString(targetB64);
    
    // Attempt 2: Spaces back to '+' (in case query parser converted '+' to ' ')
    if (!json && targetB64.includes(' ')) {
      json = tryDecodeString(targetB64.replace(/ /g, '+'));
    }
    
    // Attempt 3: Percent decode then try (in case input was double URL-encoded)
    if (!json) {
      try {
        const pctDecoded = decodeURIComponent(targetB64);
        if (pctDecoded !== targetB64) {
          json = tryDecodeString(pctDecoded);
          if (!json && pctDecoded.includes(' ')) {
            json = tryDecodeString(pctDecoded.replace(/ /g, '+'));
          }
        }
      } catch (e) {}
    }
    
    // Attempt 4: Percent decode URL safe transformation fallback
    if (!json) {
      try {
        const pctDecoded = decodeURIComponent(targetB64.replace(/ /g, '+'));
        json = tryDecodeString(pctDecoded);
      } catch (e) {}
    }

    // Attempt 5: Decode directly from raw btoa binary as last resort fallback
    if (!json) {
      try {
        const decodedFallback = atob(targetB64);
        const trimmed = decodedFallback.trim();
        if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
          const parsed = JSON.parse(trimmed);
          if (parsed && typeof parsed === 'object' && ('r' in parsed || 'na' in parsed || 'ne' in parsed)) {
            json = trimmed;
          }
        }
      } catch (e) {}
    }

    if (!json) {
      return null;
    }

    const data = JSON.parse(json);
    
    return {
      registryNumber: data.r,
      applicationNumber: data.a,
      applicationDate: data.ad,
      registrationDate: data.rd,
      expiryDate: data.ed || "2036-01-01",
      journalNumber: data.jn || "732",
      journalPageNumber: data.jp || "45",
      trademarkNameEn: data.ne,
      trademarkNameAr: data.na,
      trademarkLogoUrl: data.lo || "gold-emblem",
      trademarkType: data.ty || "Composite",
      niceClass: data.c,
      ownerNameEn: data.oe,
      ownerNameAr: data.oa,
      goodsDescriptionEn: data.de,
      goodsDescriptionAr: data.da,
      ownerLegalStatusEn: data.le || "Corporation",
      ownerLegalStatusAr: data.la || "شركة ذات مسؤولية محدودة",
      securityHash: data.h || "IQ-TM-VERIFIED"
    };
  } catch (err) {
    return null;
  }
}

// Beautiful procedural placeholder logo generator based on trademark name
const LogoPresetRenderer = ({ placeholderType, name }: { placeholderType: string, name: string }) => {
  const letters = name ? name.substring(0, 2).toUpperCase() : "IQ";
  
  if (placeholderType === 'telecom') {
    return (
      <svg className="w-16 h-16 text-emerald-800" viewBox="0 0 100 100" fill="currentColor">
        <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 2" />
        <path d="M50 20 L50 80 M20 50 L80 50" stroke="currentColor" strokeWidth="2" />
        <circle cx="50" cy="50" r="15" fill="currentColor" opacity="0.2" />
        <path d="M35 35 Q50 20 65 35" fill="none" stroke="currentColor" strokeWidth="3" />
        <path d="M25 25 Q50 5 75 25" fill="none" stroke="currentColor" strokeWidth="2" />
        <circle cx="50" cy="50" r="6" fill="currentColor" />
      </svg>
    );
  }
  
  if (placeholderType === 'coffee') {
    return (
      <svg className="w-16 h-16 text-amber-800" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2.5">
        <path d="M30 40 C30 25 70 25 70 40 C70 55 30 55 30 40 Z" fill="currentColor" fillOpacity="0.1" />
        <path d="M70 35 C78 35 78 45 70 45" />
        <path d="M40 65 Q50 80 60 65" />
        <path d="M30 65 L70 65" strokeWidth="3" />
        <path d="M45 25 Q48 15 43 10 M52 25 Q55 12 50 10 M38 25 Q40 18 36 12" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  if (placeholderType === 'shield') {
    return (
      <svg className="w-16 h-16 text-red-900" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3">
        <path d="M50 15 C65 15 80 10 80 10 L80 40 C80 65 50 85 50 85 C50 85 20 65 20 40 L20 10 C20 10 35 15 50 15 Z" fill="currentColor" fillOpacity="0.1" />
        <circle cx="50" cy="45" r="10" strokeWidth="2" strokeDasharray="3 1" />
        <text x="50" y="55" textAnchor="middle" fill="currentColor" fontSize="11" fontWeight="bold" stroke="none" className="font-mono">
          {letters}
        </text>
      </svg>
    );
  }

  // Classic default golden crest monogram
  return (
    <div className="w-16 h-16 border-2 border-amber-600 rounded-full flex items-center justify-center bg-amber-50/50 shadow-inner relative overflow-hidden">
      <div className="absolute inset-1 border border-amber-500 border-dashed rounded-full" />
      <span className="text-xl font-bold font-serif-eng text-amber-800 tracking-wider relative z-10">{letters}</span>
    </div>
  );
};

export default function App() {
  // Check if we are booted into Verification Portal mode directly via QR Code scan
  const [verificationMode, setVerificationMode] = useState<boolean>(false);
  const [scannedData, setScannedData] = useState<Partial<TrademarkCertificate> | null>(null);
  const [verifyTab, setVerifyTab] = useState<'ledger' | 'certificate'>('ledger');
  
  // App database lookup search states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchError, setSearchError] = useState<string | null>(null);
  const [searchResult, setSearchResult] = useState<TrademarkCertificate | null>(null);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [copiedRecentId, setCopiedRecentId] = useState<string | null>(null);

  // App persistent registration database loaded from localStorage, pre-populated with default certified presets
  const [registeredTrademarks, setRegisteredTrademarks] = useState<TrademarkCertificate[]>(() => {
    try {
      const stored = localStorage.getItem('iraq_registered_trademarks_v2');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Error reading from localStorage", e);
    }
    const defaults = [
      MOCK_CERTIFICATE_PRESETS.iraqCell,
      MOCK_CERTIFICATE_PRESETS.tigrisCoffee
    ];
    if (MOCK_CERTIFICATE_PRESETS.mesopotamianFarms) {
      defaults.push(MOCK_CERTIFICATE_PRESETS.mesopotamianFarms);
    }
    return defaults;
  });

  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  const saveActiveCertToDatabase = () => {
    try {
      const existsIdx = registeredTrademarks.findIndex(t => t.registryNumber === cert.registryNumber);
      let updatedList = [...registeredTrademarks];
      
      const certToSave = {
        ...cert,
        id: cert.id || "manual-saved-" + Date.now().toString(36),
      };

      if (existsIdx !== -1) {
        updatedList[existsIdx] = certToSave;
      } else {
        updatedList.push(certToSave);
      }

      setRegisteredTrademarks(updatedList);
      localStorage.setItem('iraq_registered_trademarks_v2', JSON.stringify(updatedList));
      
      setSaveFeedback(`تم حفظ وتسجيل العلامة في السجل الرقمي برقم: ${cert.registryNumber}`);
      setTimeout(() => setSaveFeedback(null), 4000);
    } catch (err) {
      console.error("Failed to save to registry database", err);
      setSaveFeedback("خطأ في حفظ السجل المحلي");
      setTimeout(() => setSaveFeedback(null), 3500);
    }
  };

  // App primary state
  const [cert, setCert] = useState<TrademarkCertificate>(MOCK_CERTIFICATE_PRESETS.iraqCell);
  
  // Custom logo upload
  const [uploadedLogo, setUploadedLogo] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Active view tab: 'preview' (workbench), 'portal' (registry check simulation), or 'database' (online database viewer JSON generator)
  const [activeTab, setActiveTab] = useState<'preview' | 'portal' | 'database'>('preview');
  const [siteMode, setSiteMode] = useState<'admin' | 'public'>('public');
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState<boolean>(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [qrCodeOption, setQrCodeOption] = useState<'official' | 'testable'>('official');
  
  // Dynamic Certificate Print Language Layout: bilingual (default Iraqi style), english, arabic
  const [certLanguage, setCertLanguage] = useState<'bilingual' | 'english' | 'arabic'>('bilingual');
  
  // Custom generated URL share state
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [copiedRawText, setCopiedRawText] = useState<boolean>(false);
  const [copiedDatabaseJson, setCopiedDatabaseJson] = useState<boolean>(false);

  // AI Autocomplete state
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [aiStatus, setAiStatus] = useState<string>("");
  const [aiError, setAiError] = useState<string>("");

  const handleAiFill = async () => {
    if (!cert.trademarkNameEn && !cert.trademarkNameAr) {
      setAiError("Please type a Brand Name first to generate details!");
      return;
    }
    setAiLoading(true);
    setAiError("");
    setAiStatus("Analyzing brand name and trademark category...");
    
    // Smooth status transitions during processing
    const statusSequence = [
      { text: "Translating to official Iraqi registry Arabic...", delay: 1000 },
      { text: "Selecting matching Nice Classification Category...", delay: 2000 },
      { text: "Drafting bilingual protection specifications...", delay: 3200 },
      { text: "Calculating 10-year expiration starting after 2019...", delay: 4400 },
      { text: "Structuring digital seal and handwritten signature coordinates...", delay: 5500 }
    ];

    const timeouts = statusSequence.map(it => 
      setTimeout(() => setAiStatus(it.text), it.delay)
    );

    try {
      const response = await fetch("/api/generate-certificate-details", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          brandName: cert.trademarkNameEn || cert.trademarkNameAr,
          ownerName: cert.ownerNameEn || cert.ownerNameAr || "REGISTERED PROPRIETOR",
          logoType: cert.trademarkLogoUrl
        })
      });

      if (!response.ok) {
        throw new Error("Failed to load AI Autocomplete. Please try again.");
      }

      const aiData = await response.json();
      
      // Ensure we start from 2019 or onwards
      let appDate = aiData.applicationDate || "2020-03-12";
      let regDate = aiData.registrationDate || "2522-09-18"; 

      try {
        let appYear = new Date(appDate).getFullYear();
        if (isNaN(appYear) || appYear < 2019) {
          appDate = "2020-03-12";
        }
        let regYear = new Date(regDate).getFullYear();
        if (isNaN(regYear) || regYear < 2019) {
          regDate = "2020-09-18";
        }
      } catch (e) {
        appDate = "2020-03-12";
        regDate = "2020-09-18";
      }

      // 10 years validity period calculation
      let expiryDateStr = "2030-09-18";
      try {
        const origReg = new Date(regDate);
        const origExp = new Date(origReg);
        origExp.setFullYear(origReg.getFullYear() + 10);
        expiryDateStr = origExp.toISOString().split('T')[0];
      } catch (e) {}

      setCert(prev => ({
        ...prev,
        registryNumber: aiData.registryNumber || prev.registryNumber,
        applicationNumber: aiData.applicationNumber || prev.applicationNumber,
        applicationDate: appDate,
        registrationDate: regDate,
        expiryDate: expiryDateStr,
        journalNumber: aiData.journalNumber || prev.journalNumber,
        journalPageNumber: aiData.journalPageNumber || prev.journalPageNumber,
        trademarkNameEn: (aiData.trademarkNameEn || prev.trademarkNameEn || "").toUpperCase(),
        trademarkNameAr: aiData.trademarkNameAr || prev.trademarkNameAr,
        trademarkType: aiData.trademarkType || prev.trademarkType,
        trademarkTypeAr: aiData.trademarkTypeAr || prev.trademarkTypeAr,
        niceClass: Number(aiData.niceClass || prev.niceClass),
        goodsDescriptionEn: aiData.goodsDescriptionEn || prev.goodsDescriptionEn,
        goodsDescriptionAr: aiData.goodsDescriptionAr || prev.goodsDescriptionAr,
        ownerNameEn: (aiData.ownerNameEn || prev.ownerNameEn || "").toUpperCase(),
        ownerNameAr: aiData.ownerNameAr || prev.ownerNameAr,
        ownerNationalityEn: aiData.ownerNationalityEn || prev.ownerNationalityEn,
        ownerNationalityAr: aiData.ownerNationalityAr || prev.ownerNationalityAr,
        ownerAddressEn: aiData.ownerAddressEn || prev.ownerAddressEn,
        ownerAddressAr: aiData.ownerAddressAr || prev.ownerAddressAr,
        ownerLegalStatusEn: aiData.ownerLegalStatusEn || prev.ownerLegalStatusEn,
        ownerLegalStatusAr: aiData.ownerLegalStatusAr || prev.ownerLegalStatusAr,
        registrarNameEn: aiData.registrarNameEn || prev.registrarNameEn,
        registrarNameAr: aiData.registrarNameAr || prev.registrarNameAr,
        registrarTitleEn: aiData.registrarTitleEn || prev.registrarTitleEn,
        registrarTitleAr: aiData.registrarTitleAr || prev.registrarTitleAr,
        registrarSignatureOption: 'wet-ink', // Force handwritten signature by default
        securityHash: aiData.securityHash || prev.securityHash
      }));

      setAiStatus("");
    } catch (err: any) {
      setAiError(err?.message || "Check your internet connection or try again.");
    } finally {
      timeouts.forEach(clearTimeout);
      setAiLoading(false);
    }
  };

  // Parse URL search parameters on load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verifyPayload = params.get('v');
    const pathname = window.location.pathname;

    if (verifyPayload) {
      const decoded = decompressUrl(verifyPayload);
      if (decoded) {
        setScannedData(decoded);
        setVerificationMode(true);
        // Sync cert state as well so verification has access
        setCert({
          id: "scanned",
          registryNumber: decoded.registryNumber || "N/A",
          applicationNumber: decoded.applicationNumber || "N/A",
          applicationDate: decoded.applicationDate || "N/A",
          registrationDate: decoded.registrationDate || "N/A",
          expiryDate: decoded.expiryDate || "N/A",
          journalNumber: decoded.journalNumber || "N/A",
          journalPageNumber: decoded.journalPageNumber || "N/A",
          trademarkNameEn: decoded.trademarkNameEn || "N/A",
          trademarkNameAr: decoded.trademarkNameAr || "N/A",
          trademarkLogoUrl: decoded.trademarkLogoUrl || "gold-emblem",
          trademarkLogoName: "scanned_logo.png",
          trademarkType: decoded.trademarkType as any || "Composite",
          trademarkTypeAr: decoded.trademarkType === "Word" ? "لفظية" : "مشتركة",
          niceClass: decoded.niceClass || 1,
          goodsDescriptionEn: decoded.goodsDescriptionEn || "N/A",
          goodsDescriptionAr: decoded.goodsDescriptionAr || "N/A",
          ownerNameEn: decoded.ownerNameEn || "N/A",
          ownerNameAr: decoded.ownerNameAr || "N/A",
          ownerNationalityEn: "Foreign Registered Corporation",
          ownerNationalityAr: "شركة أجنبية مسجلة",
          ownerAddressEn: decoded.ownerAddressEn || "N/A",
          ownerAddressAr: decoded.ownerAddressAr || "N/A",
          ownerLegalStatusEn: decoded.ownerLegalStatusEn || "Corporation",
          ownerLegalStatusAr: decoded.ownerLegalStatusAr || "منشأة تجارية",
          registrarNameEn: "Adnan M. Al-Khafaji",
          registrarNameAr: "عدنان محمد الخفاجي",
          registrarTitleEn: "Registrar of Intellectual Property & Trademarks",
          registrarTitleAr: "مسجل الملكية الصناعية والعلامات التجارية",
          registrarSignatureOption: "stamp-only",
          enableGoldSeal: true,
          enableRepublicRibbon: true,
          enableGuillocheBg: true,
          securityHash: decoded.securityHash || "VERIFIED-IQ"
        });
      }
    } else if (pathname.includes('/verify/')) {
      const parts = pathname.split('/verify/');
      const possibleRegId = parts[parts.length - 1]?.trim();
      if (possibleRegId) {
        let list: TrademarkCertificate[] = [];
        try {
          const stored = localStorage.getItem('iraq_registered_trademarks_v2');
          if (stored) {
            list = JSON.parse(stored);
          }
        } catch (e) {}
        if (list.length === 0) {
          list = [
            MOCK_CERTIFICATE_PRESETS.iraqCell,
            MOCK_CERTIFICATE_PRESETS.tigrisCoffee
          ];
          if (MOCK_CERTIFICATE_PRESETS.mesopotamianFarms) {
            list.push(MOCK_CERTIFICATE_PRESETS.mesopotamianFarms);
          }
        }
        
        const found = list.find(t => t.registryNumber === possibleRegId);
        if (found) {
          setScannedData(found);
          setVerificationMode(true);
          setCert(found);
        } else {
          setSearchQuery(possibleRegId);
          setVerifyTab('ledger');
          setVerificationMode(false);
          setTimeout(() => {
            handleDatabaseSearch(possibleRegId);
          }, 400);
        }
      }
    }
  }, [registeredTrademarks]);

  // Update dates automatically when typing
  const handleDateChange = (field: 'applicationDate' | 'registrationDate', value: string) => {
    const updated = { ...cert, [field]: value };
    
    // Automatically project expiry date exactly 10 years later for Iraq
    if (field === 'applicationDate' && value) {
      try {
        const d = new Date(value);
        if (!isNaN(d.getTime())) {
          d.setFullYear(d.getFullYear() + 10);
          updated.expiryDate = d.toISOString().split('T')[0];
        }
      } catch (e) {}
    }
    setCert(updated);
  };

  // Toggle pre-loaded presets
  const applyPreset = (presetKey: string) => {
    if (MOCK_CERTIFICATE_PRESETS[presetKey]) {
      setCert(MOCK_CERTIFICATE_PRESETS[presetKey]);
      setUploadedLogo(null);
    }
  };

  // Automatically configure Nice Class default goods descriptions on class selection
  const handleNiceClassSelector = (classNum: number) => {
    const p = NICE_CLASSES.find(x => x.classNumber === classNum);
    if (p) {
      setCert(prev => ({
        ...prev,
        niceClass: classNum,
        goodsDescriptionEn: p.defaultGoodsEn,
        goodsDescriptionAr: p.defaultGoodsAr
      }));
    }
  };

  // Quick Random Certificate Registry generator for realistic lookups
  const randomizeRegistryNumbers = () => {
    const randomReg = Math.floor(100000 + Math.random() * 900000).toString();
    const randomAppYear = new Date().getFullYear();
    const randomAppNum = Math.floor(1000 + Math.random() * 8999).toString();
    const randomHash = `IQ-TM-${randomAppNum}-${randomReg}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    setCert(prev => ({
      ...prev,
      registryNumber: randomReg,
      applicationNumber: `${randomAppYear}/${randomAppNum}`,
      securityHash: randomHash
    }));
  };

  // Safe file uploader to base64
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedLogo(reader.result as string);
        setCert(prev => ({
          ...prev,
          trademarkLogoUrl: "uploaded",
          trademarkLogoName: file.name
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Generate dynamic URL with full certificate parameters
  const getVerificationUrl = () => {
    const base = window.location.origin;
    if (qrCodeOption === 'official') {
      return `${base}/verify/${cert.registryNumber}`;
    }
    return getCompressedUrl(cert);
  };

  // Handle printing A4 window trigger
  const triggerPrint = () => {
    window.print();
  };

  // Copy Link to clipboard
  const copyShareLink = () => {
    const url = getVerificationUrl();
    navigator.clipboard.writeText(url).then(() => {
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    });
  };

  // Perform database search based on Registration ID, Brand Name, or pasted share link URL
  const handleDatabaseSearch = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) {
      setSearchError("Please enter a Registration ID, Brand Name, or paste a Certificate Share Link.");
      setSearchResult(null);
      return;
    }

    setIsSearching(true);
    setSearchError(null);

    // Simulate network latency for matching the database registry in Iraq (600ms)
    setTimeout(() => {
      let foundCert: Partial<TrademarkCertificate> | null = null;
      
      // 1. Check if the query is a full URL containing '?v=' or '&v='
      if (trimmed.includes('v=')) {
        try {
          const urlObj = new URL(trimmed);
          const v = urlObj.searchParams.get('v');
          if (v) {
            foundCert = decompressUrl(v);
          }
        } catch (e) {
          // Fallback parsing for partial links or copy-pasted trailing strings
          const match = trimmed.match(/[?&]v=([^&]+)/);
          if (match && match[1]) {
            foundCert = decompressUrl(match[1]);
          }
        }
      }

      // 2. Check if the raw string pasted is a Base64 encoded payload
      if (!foundCert) {
        const decoded = decompressUrl(trimmed);
        if (decoded) {
          foundCert = decoded;
        }
      }

      // 3. Search preset databases and registered trademarks
      if (!foundCert) {
        const lowerQuery = trimmed.toLowerCase();
        const foundInRegistry = registeredTrademarks.find(p => 
          p.registryNumber === trimmed ||
          p.trademarkNameEn.toLowerCase().includes(lowerQuery) ||
          p.trademarkNameAr.includes(trimmed)
        );
        if (foundInRegistry) {
          foundCert = foundInRegistry;
        }
      }

      // 4. Search active custom draft state
      if (!foundCert) {
        const lowerQuery = trimmed.toLowerCase();
        if (
          cert.registryNumber === trimmed ||
          cert.trademarkNameEn.toLowerCase().includes(lowerQuery) ||
          cert.trademarkNameAr.includes(trimmed)
        ) {
          foundCert = cert;
        }
      }

      setIsSearching(false);

      if (foundCert) {
        // Hydrate partial metadata to complete TrademarkCertificate structure
        const hydratedCert: TrademarkCertificate = {
          id: foundCert.id || "searched-registry-" + Math.random().toString(36).substring(2, 6),
          registryNumber: foundCert.registryNumber || "N/A",
          applicationNumber: foundCert.applicationNumber || "N/A",
          applicationDate: foundCert.applicationDate || "N/A",
          registrationDate: foundCert.registrationDate || "N/A",
          expiryDate: foundCert.expiryDate || "N/A",
          journalNumber: foundCert.journalNumber || "N/A",
          journalPageNumber: foundCert.journalPageNumber || "N/A",
          trademarkNameEn: foundCert.trademarkNameEn || "N/A",
          trademarkNameAr: foundCert.trademarkNameAr || "N/A",
          trademarkLogoUrl: foundCert.trademarkLogoUrl || "gold-emblem",
          trademarkLogoName: foundCert.trademarkLogoName || "logo.png",
          trademarkType: foundCert.trademarkType || "Composite",
          trademarkTypeAr: foundCert.trademarkTypeAr || "مشتركة",
          niceClass: foundCert.niceClass || 1,
          goodsDescriptionEn: foundCert.goodsDescriptionEn || "N/A",
          goodsDescriptionAr: foundCert.goodsDescriptionAr || "N/A",
          ownerNameEn: foundCert.ownerNameEn || "N/A",
          ownerNameAr: foundCert.ownerNameAr || "N/A",
          ownerNationalityEn: foundCert.ownerNationalityEn || "Iraqi Registered Enterprise",
          ownerNationalityAr: foundCert.ownerNationalityAr || "منشأة مسجلة في جمهورية العراق",
          ownerAddressEn: foundCert.ownerAddressEn || "Baghdad, Iraq",
          ownerAddressAr: foundCert.ownerAddressAr || "بغداد، جمهورية العراق",
          ownerLegalStatusEn: foundCert.ownerLegalStatusEn || "Corporation",
          ownerLegalStatusAr: foundCert.ownerLegalStatusAr || "منشأة ذات مسؤولية محدودة",
          registrarNameEn: foundCert.registrarNameEn || "Adnan M. Al-Khafaji",
          registrarNameAr: foundCert.registrarNameAr || "عدنان محمد الخفاجي",
          registrarTitleEn: foundCert.registrarTitleEn || "Registrar of Intellectual Property & Trademarks",
          registrarTitleAr: foundCert.registrarTitleAr || "مسجل الملكية الصناعية والعلامات التجارية",
          registrarSignatureOption: foundCert.registrarSignatureOption || "stamp-only",
          enableGoldSeal: foundCert.enableGoldSeal !== undefined ? foundCert.enableGoldSeal : true,
          enableRepublicRibbon: foundCert.enableRepublicRibbon !== undefined ? foundCert.enableRepublicRibbon : true,
          enableGuillocheBg: foundCert.enableGuillocheBg !== undefined ? foundCert.enableGuillocheBg : true,
          securityHash: foundCert.securityHash || "VERIFIED-IQ"
        };
        setSearchResult(hydratedCert);
      } else {
        setSearchError("No active registry match found for this search string or URL link. Please make sure the ID is correct or the URL contains a valid '?v=' parameter.");
        setSearchResult(null);
      }
    }, 600);
  };

  // Shared Iraqi State Eagle of Saladin Emblem Path
  const IraqiEmblemSVG = ({ className = "w-24 h-24" }: { className?: string }) => (
    <svg className={className} viewBox="0 0 100 115" fill="none" stroke="currentColor" strokeWidth="1.5">
      {/* Dynamic central stylized Eagle of Saladin representation */}
      {/* Crown plume */}
      <path d="M47 3 L53 3 L51 9 L49 9 Z" fill="currentColor" />
      {/* Head & beak */}
      <path d="M46 9 C46 9 50 5 54 9 L54 13 L47 16 Z" fill="currentColor" />
      <path d="M54 11 L58 13 L54 15 Z" fill="currentColor" />
      {/* Eye */}
      <circle cx="50" cy="11" r="1.2" fill="white" />
      
      {/* Wing Left */}
      <path d="M43 18 C38 18 25 35 22 55 C20 70 24 85 24 85 L28 85 C28 85 27 65 31 50 C33 40 43 25 43 25 Z" fill="currentColor" />
      <path d="M40 22 C35 25 22 45 20 62 C18 78 20 90 20 90 L23 90 C23 90 22 75 27 58 Q31 42 40 25 Z" fill="currentColor" opacity="0.85" />
      
      {/* Wing Right */}
      <path d="M57 18 C62 18 75 35 78 55 C80 70 76 85 76 85 L72 85 C72 85 73 65 69 50 C67 40 57 25 57 25 Z" fill="currentColor" />
      <path d="M60 22 C65 25 78 45 80 62 C82 78 80 90 80 90 L77 90 C77 90 78 75 73 58 Q69 42 60 25 Z" fill="currentColor" opacity="0.85" />
      
      {/* Tail feathers */}
      <path d="M42 85 L58 85 L56 100 L44 100 L42 85 Z" fill="currentColor" />
      <path d="M46 100 L54 100 L52 110 L48 110 Z" fill="currentColor" opacity="0.9" />

      {/* Central Iraqi National Shield */}
      <g stroke="none">
        <path d="M37 25 L63 25 L63 60 C63 70 50 78 50 78 C50 78 37 70 37 60 Z" fill="#B11C1C" /> {/* Red head */}
        <path d="M37 42 H63 V56 H37 Z" fill="#FFFFFF" /> {/* White middle */}
        <path d="M37 56 L63 56 L63 60 C63 70 50 78 50 78 C50 78 37 70 37 60 Z" fill="#1C6627" /> {/* Green base */}
        
        {/* Subtle Arabic Golden calligraphy for Allahu Akbar inside white shield portion */}
        <text x="50" y="52" textAnchor="middle" fill="#1C6627" fontSize="5" fontWeight="bold" fontFamily="sans-serif">الله أكبر</text>
      </g>
      
      {/* Legal Tablet Base */}
      <rect x="30" y="80" width="40" height="6" rx="2" fill="#E67E22" stroke="none" />
      <text x="50" y="84" textAnchor="middle" fill="black" fontSize="4" fontWeight="bold" stroke="none">جمهورية العراق</text>
    </svg>
  );

  // Return Verification Screen if scanned/verify URL parameters are caught
  if (verificationMode) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col antialiased">
        {/* Government Portal Nav Bar */}
        <header className="bg-slate-950 border-b border-emerald-900/40 px-6 py-4 sticky top-0 z-50">
          <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-950/80 border border-emerald-500/30 rounded-xl text-emerald-400">
                <Shield className="w-6 h-6" />
              </div>
              <div className="text-right sm:text-left">
                <h1 className="text-sm font-semibold tracking-wide text-emerald-400 font-mono">PORTAL OF INTELLECTUAL PROPERTY</h1>
                <p className="text-xs text-slate-400">Ministry of Industry & Minerals • Republic of Iraq</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => {
                  // Exit verification mode and load the creator sandbox with this certificate data
                  setVerificationMode(false);
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-2 transition"
              >
                <Edit className="w-4 h-4" />
                <span>Open in Creator Studio</span>
              </button>
              
              <button 
                onClick={() => window.print()}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs flex items-center gap-2 transition shadow-lg shadow-emerald-900/30"
              >
                <Printer className="w-4 h-4" />
                <span>Print Copy</span>
              </button>
            </div>
          </div>
        </header>

        {/* Verification Body */}
        <main className="flex-1 py-10 px-4 max-w-4xl mx-auto w-full">
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-950 border border-emerald-500/25 rounded-2xl p-6 sm:p-10 shadow-2xl relative overflow-hidden"
          >
            {/* Security watermark pattern */}
            <div className="absolute inset-0 opacity-5 pointer-events-none bg-repeat guilloche-pattern" />
            
            {/* Status indicator badge */}
            <div className="flex flex-col items-center text-center pb-8 border-b border-slate-800/80 relative z-10">
              <div className="w-16 h-16 bg-emerald-500/20 border-2 border-emerald-500 rounded-full flex items-center justify-center text-emerald-400 mb-4 animate-pulse">
                <CheckCircle className="w-10 h-10" />
              </div>
              
              <span className="text-xs font-bold font-mono px-3 py-1 bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 rounded-full uppercase tracking-widest">
                ✓ Cryptographically Verified
              </span>
              
              <h2 className="text-2xl font-bold font-amiri text-slate-100 mt-3 tracking-wide">
                وزارة الصناعة والمعادن • جمهورية العراق
              </h2>
              <p className="text-xs mt-1 text-slate-400">
                Official Industrial Development Authority Patent & Trademark Ledger Verification System
              </p>
            </div>

            {/* View Mode Switching Controls */}
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between border-b border-slate-800/50 pb-6 relative z-10 my-4">
              {/* Document/Ledger Tab buttons */}
              <div className="flex p-0.5 bg-slate-900 border border-slate-800/85 rounded-lg w-full sm:w-auto shrink-0 select-none">
                <button
                  type="button"
                  onClick={() => setVerifyTab('ledger')}
                  className={`flex-1 sm:flex-none uppercase px-4 py-2 rounded-md text-[10px] font-bold tracking-wider transition flex items-center justify-center gap-1.5 ${verifyTab === 'ledger' ? 'bg-emerald-600 text-slate-100 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>Registry Ledger / السجل المعتمد</span>
                </button>
                <button
                  type="button"
                  onClick={() => setVerifyTab('certificate')}
                  className={`flex-1 sm:flex-none uppercase px-4 py-2 rounded-md text-[10px] font-bold tracking-wider transition flex items-center justify-center gap-1.5 ${verifyTab === 'certificate' ? 'bg-emerald-600 text-slate-100 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Official Certificate / وثيقة الشهادة</span>
                </button>
              </div>

              {/* Language Selector */}
              <div className="flex p-0.5 bg-slate-900 border border-slate-800/85 rounded-lg w-full sm:w-auto shrink-0 select-none">
                <button
                  type="button"
                  onClick={() => setCertLanguage('bilingual')}
                  className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-[10px] font-bold transition ${certLanguage === 'bilingual' ? 'bg-emerald-600/25 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Bilingual / ثنائي
                </button>
                <button
                  type="button"
                  onClick={() => setCertLanguage('english')}
                  className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-[10px] font-bold transition ${certLanguage === 'english' ? 'bg-emerald-600/25 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  English / الإنكليزية
                </button>
                <button
                  type="button"
                  onClick={() => setCertLanguage('arabic')}
                  className={`flex-1 sm:flex-none px-3 py-1.5 rounded-md text-[10px] font-bold transition ${certLanguage === 'arabic' ? 'bg-emerald-600/25 text-emerald-400 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  العربية
                </button>
              </div>
            </div>

            {verifyTab === 'ledger' ? (
              /* Dynamic scanned metadata display */
              <div className="mt-8 relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Trademark Identity Section */}
              <div className="bg-slate-900/60 p-5 rounded-xl border border-slate-800/80">
                <div className="text-emerald-500 text-xs font-bold tracking-widest font-mono mb-4 uppercase">
                  TRADEMARK CREDENTIALS / بيانات العلامة التجاريـة
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-slate-500 text-xs block font-mono">English Verbal Name / الإسم بالأجنبي</label>
                    <span className="text-base font-bold font-serif-eng text-amber-100">
                      {cert.trademarkNameEn}
                    </span>
                  </div>
                  <div>
                    <label className="text-slate-500 text-xs block font-mono">Arabic Name / الإسم بالعربي</label>
                    <span className="text-lg font-bold font-amiri text-amber-100">
                      {cert.trademarkNameAr}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="text-slate-500 text-xs block font-mono">Nice Class / فئة نيس</label>
                      <span className="text-sm font-bold text-slate-200">
                        Class {cert.niceClass} ({NICE_CLASSES.find(x => x.classNumber === cert.niceClass)?.titleEn})
                      </span>
                    </div>
                    <div>
                      <label className="text-slate-500 text-xs block font-mono">Type / نوع العلامة</label>
                      <span className="text-sm font-bold text-slate-200">
                        {cert.trademarkType} ({cert.trademarkTypeAr})
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Owner details */}
              <div className="bg-slate-900/60 p-5 rounded-xl border border-slate-800/80">
                <div className="text-emerald-500 text-xs font-bold tracking-widest font-mono mb-4 uppercase">
                  LEGAL OWNERSHIP / جهة ملكية العلامة
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-slate-500 text-xs block font-mono">Proprietor Name (EN) / المالك</label>
                    <span className="text-sm font-bold text-slate-200 block">{cert.ownerNameEn}</span>
                  </div>
                  <div>
                    <label className="text-slate-500 text-xs block font-mono">المالك ومقر التأسيس بالعربي</label>
                    <span className="text-base font-bold font-amiri text-slate-200 block">{cert.ownerNameAr}</span>
                  </div>
                  <div>
                    <label className="text-slate-500 text-xs block font-mono">Corporate Address / العنوان المسجل</label>
                    <span className="text-xs text-slate-300 block">{cert.ownerAddressEn}</span>
                    <span className="text-xs font-amiri text-slate-400 block mt-0.5">{cert.ownerAddressAr}</span>
                  </div>
                </div>
              </div>

              {/* Registry Logistics */}
              <div className="bg-slate-900/40 p-5 rounded-xl border border-slate-800/40 md:col-span-2">
                <div className="text-emerald-500 text-xs font-bold tracking-widest font-mono mb-4 uppercase">
                  RECORD LEDGER METRICS / السجل الرسمي القيادي
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                  <div>
                    <span className="text-slate-500 text-xs block font-mono">Registration ID / رقم التسجيل</span>
                    <span className="text-sm font-bold text-slate-100 font-mono text-amber-500">
                      IQ-REG-{cert.registryNumber}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-xs block font-mono">Filing Application / رقم الطلب</span>
                    <span className="text-sm font-bold text-slate-100 font-mono">
                      {cert.applicationNumber}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-xs block font-mono">Registration Date / تاريخ التسجيل</span>
                    <span className="text-xs font-bold text-slate-300 font-mono">
                      {cert.registrationDate}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-xs block font-mono">Renewal Expiry / نهاية الحماية</span>
                    <span className="text-xs font-bold text-slate-300 font-mono">
                      {cert.expiryDate}
                    </span>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-800/80">
                  <span className="text-slate-500 text-xs block font-mono">Official List of Goods & Services / قائمة السلع والخـدمات وعناصر الحماية</span>
                  <p className="text-xs text-slate-300 font-sans mt-1.5 leading-relaxed bg-slate-950/80 p-3 rounded-lg border border-slate-900">
                    {cert.goodsDescriptionEn}
                  </p>
                  <p className="text-sm font-amiri text-slate-300 mt-2 leading-relaxed bg-slate-950/80 p-3 rounded-lg border border-slate-900 text-right">
                    {cert.goodsDescriptionAr}
                  </p>
                </div>
              </div>
            </div>
            ) : (
              /* A4 Digital Replica view of the actual Certificate Document */
              <div className="mt-8 relative z-10 space-y-4">
                <div className="bg-[#fcfaf4] border-8 border-[#d4be8a] text-stone-900 rounded-xl p-5 sm:p-8 shadow-inner relative max-w-full overflow-hidden select-text text-left">
                  {/* Watermark eagle backdrop */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.035] pointer-events-none">
                    <IraqiEmblemSVG className="w-80 h-80 text-stone-700" />
                  </div>
                  
                  {/* Decorative golden thin frame */}
                  <div className="absolute inset-1.5 border border-[#c4af78]/40 pointer-events-none" />

                  {/* Header metadata */}
                  <div className="flex justify-between items-start gap-4 border-b pb-4 border-stone-200/80">
                    {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                      <div className="text-[10px] space-y-0.5 leading-tight font-sans">
                        <p className="font-bold text-stone-800">REPUBLIC OF IRAQ</p>
                        <p className="text-stone-600 text-[9px]">Ministry of Industry & Minerals</p>
                        <p className="text-stone-500 text-[8px]">Intellectual Property Trademark Division</p>
                        <p className="text-stone-400 text-[8px] font-mono">Reg. No: #{cert.registryNumber}</p>
                      </div>
                    )}

                    {certLanguage === 'bilingual' && (
                      <div className="hidden sm:block shrink-0">
                        <IraqiEmblemSVG className="w-12 h-12 text-stone-700" />
                      </div>
                    )}

                    {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                      <div className="text-[11px] text-right space-y-0.5 leading-tight font-amiri" dir="rtl">
                        <p className="font-bold text-stone-800">جمهورية العراق</p>
                        <p className="text-stone-600 text-[10px]">وزارة الصناعة والمعادن</p>
                        <p className="text-stone-500 text-[9px]">قسم العلامات التجارية الفكرية</p>
                        <p className="text-stone-400 text-[9px] font-mono">رقم التسجيل: #{cert.registryNumber}</p>
                      </div>
                    )}
                  </div>

                  {/* Document Title */}
                  <div className="text-center py-5 space-y-1">
                    {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                      <h4 className="text-xs font-bold tracking-widest font-mono text-amber-900">CERTIFICATE OF TRADEMARK REGISTRATION</h4>
                    )}
                    {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                      <h4 className="text-lg font-bold font-amiri text-amber-950">شهـادة تسجيـل علامـة تجاريـة رسميـة</h4>
                    )}
                  </div>

                  {/* Body values */}
                  <div className="space-y-4 text-xs">
                    {/* Brand Identifier */}
                    <div className="bg-amber-50/30 p-3 rounded border border-amber-600/10">
                      <div className="flex justify-between text-[9px] text-stone-400 font-mono pb-1 border-b border-stone-200">
                        {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                          <span>REGISTERED TRADEMARK BRAND</span>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                          <span>العلامة التجارية المقيدة بالسجلات</span>
                        )}
                      </div>
                      <div className="flex justify-between items-center pt-2 gap-4">
                        <div className="space-y-1">
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <p className="text-sm font-bold text-stone-800 font-mono">{cert.trademarkNameEn}</p>
                          )}
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <p className="text-base font-bold font-amiri text-stone-900">{cert.trademarkNameAr}</p>
                          )}
                        </div>
                        <div className="w-12 h-12 bg-white rounded border border-stone-200/80 p-1 flex items-center justify-center shrink-0">
                          {cert.trademarkLogoUrl === 'uploaded' && uploadedLogo ? (
                            <img src={uploadedLogo} alt="Logo" className="w-10 h-10 object-contain" referrerPolicy="no-referrer" />
                          ) : (
                            <LogoPresetRenderer placeholderType={cert.trademarkLogoUrl} name={cert.trademarkNameEn} />
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Owner Announcement */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-3 border border-stone-200/80 rounded bg-stone-50/50">
                        <span className="text-[9px] text-stone-400 block font-mono">OWNER / المالك المعتمد</span>
                        {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                          <p className="font-bold text-stone-800 mt-1 font-mono text-[10px]">{cert.ownerNameEn}</p>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                          <p className="font-bold font-amiri text-stone-900 mt-0.5 text-xs">{cert.ownerNameAr}</p>
                        )}
                        <p className="text-[9px] text-stone-500 mt-1 font-mono">
                          {certLanguage === 'english' ? cert.ownerNationalityEn : cert.ownerNationalityAr}
                        </p>
                        <p className="text-[8.5px] text-stone-400 leading-tight mt-0.5 truncate font-mono">
                          {certLanguage === 'english' ? cert.ownerAddressEn : cert.ownerAddressAr}
                        </p>
                      </div>

                      <div className="p-3 border border-stone-200/80 rounded bg-stone-50/50">
                        <span className="text-[9px] text-stone-400 block font-mono">NICE CLASS & SECTOR / فئة التصنيف</span>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xl font-bold font-mono text-amber-900">{cert.niceClass}</span>
                          <span className="text-[9px] font-mono text-stone-500">(Nice Standard Index)</span>
                        </div>
                        <p className="text-[9px] text-stone-500 leading-tight mt-1 line-clamp-2">
                          {certLanguage === 'english' ? cert.goodsDescriptionEn : cert.goodsDescriptionAr}
                        </p>
                      </div>
                    </div>

                    {/* Logistical dates */}
                    <div className="grid grid-cols-3 gap-2 text-center p-2 bg-stone-50/50 border border-stone-200/60 rounded text-[9px] font-mono">
                      <div>
                        <span className="text-stone-400 block text-[7.5px]">REG. DATE</span>
                        <span className="font-bold text-stone-800">{cert.registrationDate}</span>
                      </div>
                      <div>
                        <span className="text-stone-400 block text-[7.5px]">APP. DATE</span>
                        <span className="font-bold text-stone-800">{cert.applicationDate}</span>
                      </div>
                      <div>
                        <span className="text-amber-750 block text-[7.5px] font-bold">VAL. EXPIRY</span>
                        <span className="font-bold text-amber-900">{cert.expiryDate}</span>
                      </div>
                    </div>

                    {/* Signature block */}
                    <div className="pt-4 border-t border-stone-200 flex justify-between items-center">
                      <div className="text-[8.5px] text-stone-400 font-mono space-y-0.5">
                        <p>Verify Hash Check: {cert.securityHash}</p>
                        <p>Status: ACTIVE PROTECTION EXTENDER (10 YEAR VALIDITY)</p>
                      </div>
                      
                      <div className="text-right relative pr-3">
                        {/* Stamp overlay */}
                        {(cert.registrarSignatureOption === 'stamp-only' || cert.registrarSignatureOption === 'wet-ink') && (
                          <div className="absolute right-0 -top-8 w-14 h-14 rounded-full border-2 border-emerald-750/30 flex flex-col justify-center items-center opacity-40 rotate-[12deg] pointer-events-none select-none text-[5px] text-emerald-800 font-mono">
                            <span className="font-bold">Republic of Iraq</span>
                            <span>مسجل العلامات</span>
                          </div>
                        )}
                        {/* Dynamic hand calligraphy signature */}
                        {cert.registrarSignatureOption === 'wet-ink' && (
                          <div className="absolute right-2 -bottom-2 w-16 h-6 pointer-events-none opacity-80 rotate-[-5deg] z-20">
                            <svg className="w-full h-full text-blue-700" viewBox="0 0 100 40">
                              <path d="M10 25 C30 10 40 35 60 15 C75 -5 85 30 95 10 M40 28 L75 28 M20 20 Q50 5 80 32" fill="none" stroke="currentColor" strokeWidth="2.5" />
                            </svg>
                          </div>
                        )}
                        <p className="text-[10px] font-bold font-amiri text-stone-800">{certLanguage === 'english' ? cert.registrarNameEn : cert.registrarNameAr}</p>
                        <p className="text-[8px] text-stone-500 leading-tight">{certLanguage === 'english' ? cert.registrarTitleEn : cert.registrarTitleAr}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Print Quick Download action button */}
                <div className="flex justify-center">
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Official Certificate (A4 Print) / تحميل نسخة شهادة الطباعة</span>
                  </button>
                </div>
              </div>
            )}

            {/* Verification Footer Certifier Stamps */}
            <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 text-slate-400">
                  <IraqiEmblemSVG className="w-full h-full text-emerald-500/40" />
                </div>
                <div className="text-xs text-slate-400">
                  <p className="font-bold text-slate-300">Republic of Iraq Authority</p>
                  <p>Ministry Intellectual Property Office</p>
                  <p className="font-mono text-[10px] text-slate-500 mt-0.5">Signature Cryptograph: {cert.securityHash}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => {
                    const url = window.location.origin + window.location.pathname;
                    window.location.href = url;
                  }}
                  className="px-5 py-2.5 bg-emerald-600/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-600/20 text-xs font-semibold rounded-lg transition"
                >
                  Create Own Certificate
                </button>
              </div>
            </div>
          </motion.div>
          
          <div className="text-center mt-6 text-xs text-slate-500">
            This portal verifies the authenticity of the bilingual Iraqi trademark certificate. To generate custom test templates, visit the main program.
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafaf9] text-slate-800 antialiased flex flex-col work-sandbox">
      {/* Visual background accents */}
      <div className="absolute top-0 left-0 w-1/3 h-96 bg-emerald-750/[0.04] rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-1/3 h-96 bg-amber-750/[0.03] rounded-full blur-3xl pointer-events-none" />

      {/* Main Studio Navigation Header - Only shown in Admin Mode to keep the public view authentic */}
      {siteMode === 'admin' && (
        <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 backdrop-blur-md sticky top-0 z-40 no-print">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-center text-amber-500 shadow-md">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-bold font-mono tracking-widest text-amber-500 block">ADMIN DESK CONTROL</span>
                <h1 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  Iraq Trademark Office Portal
                  <span className="text-xs font-amiri text-amber-600 font-medium">سجل العلامات</span>
                </h1>
              </div>
            </div>

            {/* Quick presets controller */}
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="text-xs text-slate-400 font-mono">Example Presets:</span>
              <button 
                type="button"
                onClick={() => applyPreset('iraqCell')}
                className={`px-3 py-1.5 border rounded-lg text-xs font-medium transition ${cert.id === 'preset-1' ? 'bg-amber-500/20 border-amber-500/50 text-amber-200' : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-805'}`}
              >
                🇮🇶 IraqCell (Telecom)
              </button>
              <button 
                type="button"
                onClick={() => applyPreset('tigrisCoffee')}
                className={`px-3 py-1.5 border rounded-lg text-xs font-medium transition ${cert.id === 'preset-2' ? 'bg-amber-500/20 border-amber-500/50 text-amber-200' : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-855'}`}
              >
                ☕ Babylon Coffee (Class 43)
              </button>
              <button 
                type="button"
                onClick={() => applyPreset('mesopotamianFarms')}
                className={`px-3 py-1.5 border rounded-lg text-xs font-medium transition ${cert.id === 'preset-3' ? 'bg-amber-500/20 border-amber-500/50 text-amber-200' : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:bg-slate-855'}`}
              >
                🌾 Mesopotamian Organics (Pending Class 29)
              </button>
            </div>
          </div>
        </header>
      )}

      {/* Dynamic Simulated Browser Shell Frame / Domain Switcher Banner - Only rendered in Admin Mode */}
      {siteMode === 'admin' && (
        <div className="max-w-7xl mx-auto w-full px-4 md:px-6 lg:px-8 mt-6 no-print">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
            {/* Browser Bar Frame Chrome */}
            <div className="bg-slate-950 px-4 py-3 flex items-center justify-between gap-3 border-b border-slate-850">
              {/* Round window dots */}
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="w-3 h-3 rounded-full bg-red-500/80 block" />
                <span className="w-3 h-3 rounded-full bg-yellow-500/80 block" />
                <span className="w-3 h-3 rounded-full bg-green-500/80 block" />
              </div>
              
              {/* URL string containing current simulated domain */}
              <div className="flex-1 max-w-xl mx-auto bg-slate-900/90 border border-slate-800/80 px-4 py-1.5 rounded-lg flex items-center justify-between text-xs text-slate-300 font-mono shadow-inner select-all">
                <div className="flex items-center gap-2 truncate">
                  <Shield className="w-3.5 h-3.5 text-amber-500 animate-pulse shrink-0" />
                  <span className="text-emerald-400 font-bold shrink-0">https://</span>
                  <span className="text-slate-100 font-bold">iraqgovtradamrk.org</span>
                  <span className="text-slate-400 font-medium">/admin/registration-desk</span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 text-slate-500 text-[10px] font-bold">
                  <span className="bg-amber-500/10 border border-amber-500/30 text-amber-500 px-1.5 py-0.2 rounded-md uppercase font-bold text-[9px]">
                    🔒 Secure Admin Portal
                  </span>
                </div>
              </div>

              {/* Selector status label */}
              <div className="text-[10px] font-mono text-slate-500 hidden sm:block">Status: Connected</div>
            </div>

            {/* Site Selectors Tab-Deck */}
            <div className="p-4 bg-slate-900/60 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-slate-100 font-bold font-mono uppercase text-xs flex items-center gap-1.5 tracking-wide">
                  <span>Dual Registry Platform Controller</span>
                </h3>
                <p className="text-slate-400 text-[11px] leading-snug">
                  Manage internal trademark issuance desk or navigate the live USPTO-style public lookup directory.
                </p>
              </div>

              <div className="flex bg-slate-950 p-1.5 rounded-xl border border-slate-850/80 gap-1.5 overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setSiteMode('admin')}
                  className={`py-2 px-3 sm:px-4 rounded-lg text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${siteMode === 'admin' ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  <Shield className="w-3.5 h-3.5 shrink-0" />
                  <div className="text-left font-mono leading-none">
                    <div className="font-bold text-[10.5px] sm:text-[11px]">ADMIN DESK (iraqgovtradamrk.org)</div>
                    <div className="text-[8px] opacity-75 font-sans mt-0.5 font-normal">Create, Edit, Seal, Stamps, Sign [Private]</div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSiteMode('public')}
                  className="py-2 px-3 sm:px-4 rounded-lg text-xs font-bold transition flex items-center gap-2 whitespace-nowrap text-slate-400 hover:text-slate-200"
                >
                  <Globe className="w-3.5 h-3.5 shrink-0" />
                  <div className="text-left font-mono leading-none">
                    <div className="font-bold text-[10.5px] sm:text-[11px]">PUBLIC TSDR (iraqtrademarkdatabase.org)</div>
                    <div className="text-[8px] opacity-90 font-sans mt-0.5 font-normal">USPTO TSDR Sheets, Timelines, Details [Public]</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Sandbox Content Wrapper */}
      <div className="max-w-7xl mx-auto w-full p-4 md:p-6 lg:p-8 flex-1 relative z-10">
        <AnimatePresence mode="wait">
          {siteMode === 'public' ? (
            <motion.div
              key="public-portal-pane"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col gap-8"
            >
              <UsptoStatusView 
                currentCert={cert} 
                onSelectCert={(selected) => setCert(selected)}
                mockPresets={MOCK_CERTIFICATE_PRESETS}
                onExit={() => {
                  // Direct bypass is hidden; they must use the official password trigger in the footer
                  setShowPasswordPrompt(true);
                  const el = document.getElementById('admin-gate-footer');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
              />

              {/* Secure Private Portal Selector hidden at the absolute bottom - option soto kore nise daw */}
              <div id="admin-gate-footer" className="w-full bg-white border border-stone-200 rounded-xl p-5 shadow-sm max-w-4xl mx-auto no-print mt-4">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-center sm:text-left">
                    <p className="text-[11px] font-bold text-slate-850 font-sans">
                      نظام التحقق الإلكتروني من العلامات التجارية العراقي • جمهورية العراق
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Iraq Official Trademark Electronic Status Verification & Intellectual Property ledger query system
                    </p>
                  </div>

                  <div className="shrink-0">
                    {showPasswordPrompt ? (
                      <form 
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (passwordInput === '1234') {
                            setSiteMode('admin');
                            setPasswordError(null);
                            setPasswordInput('');
                            setShowPasswordPrompt(false);
                          } else {
                            setPasswordError('رمز المرور خاطئ / Access Code Invalid');
                          }
                        }}
                        className="flex items-center gap-1.5 bg-stone-50 border border-stone-200 rounded-lg p-1"
                      >
                        <input 
                          type="password"
                          placeholder="Passcode..."
                          value={passwordInput}
                          onChange={(e) => setPasswordInput(e.target.value)}
                          className="px-2 py-1 bg-white border border-stone-200 rounded text-xs text-stone-800 font-mono text-center w-24 focus:outline-none"
                          autoFocus
                        />
                        <button 
                          type="submit"
                          className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-[11px] px-3 py-1 rounded transition"
                        >
                          دخول / OK
                        </button>
                        <button 
                          type="button" 
                          onClick={() => {
                            setShowPasswordPrompt(false);
                            setPasswordError(null);
                            setPasswordInput('');
                          }}
                          className="text-stone-400 hover:text-stone-700 text-[10px] px-1 font-semibold"
                        >
                          إلغاء
                        </button>
                      </form>
                    ) : (
                      <button 
                        type="button"
                        onClick={() => setShowPasswordPrompt(true)}
                        className="py-1 px-2.5 hover:bg-stone-100 hover:border-stone-300 border border-stone-200 rounded-lg transition text-[10px] font-mono text-slate-400 font-bold uppercase flex items-center justify-center gap-1.5 shadow-sm bg-white"
                      >
                        <Shield className="w-3 h-3 text-stone-400" />
                        <span>🔒 ADMIN PANEL SWITCHER</span>
                      </button>
                    )}
                  </div>
                </div>
                {passwordError && (
                  <p className="text-red-700 font-mono text-[9.5px] mt-2 text-center sm:text-right font-bold">
                    ⚠️ {passwordError}
                  </p>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="admin-workspace-pane"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              {/* Left column editing panel (5cols) - completely hidden during active printing */}
              <section className="lg:col-span-5 space-y-6 no-print">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-5">
              <h2 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wider font-mono">
                <Edit className="w-4 h-4 text-amber-400" />
                <span>Certificate Customizer</span>
              </h2>
              <button 
                onClick={randomizeRegistryNumbers}
                className="p-1 px-2 hover:bg-slate-800 rounded text-[10px] text-slate-400 font-mono flex items-center gap-1.5 border border-slate-800 transition"
                title="Randomize Registrations IDs"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reg IDs</span>
              </button>
            </div>

            {/* Quick AI Autocomplete Panel */}
            <div className="mb-6 p-4 bg-gradient-to-br from-amber-500/10 via-amber-950/20 to-slate-950/95 border border-amber-500/30 rounded-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                <h3 className="font-bold text-xs uppercase tracking-wide text-amber-200 font-mono">
                  Iraq AI Registry Autocomplete
                </h3>
                <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded-full border border-amber-500/30 font-sans tracking-tight">Active</span>
              </div>
              <p className="text-[11px] text-slate-350 leading-relaxed mb-3">
                Enter your **Brand Name** and **Owner Name** below, then tap to automatically fill matching Nice categories, bilingual Arabic translations, journal records, 10-year timelines (from 2019+), and realistic handwritten signatures.
              </p>
              <button
                type="button"
                onClick={handleAiFill}
                disabled={aiLoading}
                className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-450 disabled:bg-slate-800 text-slate-950 font-bold rounded-lg text-xs flex items-center justify-center gap-2 transition-all duration-300 active:scale-[0.98] shadow-lg shadow-amber-500/10 cursor-pointer"
              >
                {aiLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-950" />
                    <span className="font-mono">{aiStatus}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Generate Complete Dual-Lang Certificate</span>
                  </>
                )}
              </button>
              {aiError && (
                <div className="mt-2 text-[10px] text-rose-400 flex items-center gap-1.5 bg-rose-950/40 p-2 rounded border border-rose-900/40">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  <span>{aiError}</span>
                </div>
              )}
            </div>

            {/* Dual Lang inputs: Trademark details */}
            <div className="space-y-4">
              <div>
                <label className="block text-slate-400 text-xs font-bold mb-1 uppercase tracking-wider font-mono">
                  Trademark Name (English)
                </label>
                <input 
                  type="text" 
                  value={cert.trademarkNameEn}
                  onChange={(e) => setCert({ ...cert, trademarkNameEn: e.target.value.toUpperCase() })}
                  maxLength={50}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 text-slate-100 font-mono tracking-wide"
                  placeholder="e.g. RAPID TELECOM SERVICES"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-xs font-bold mb-1 text-right uppercase tracking-wider font-mono">
                  إسم العلامة بالمحرر العربي (Trademark Name Arabic)
                </label>
                <input 
                  type="text" 
                  value={cert.trademarkNameAr}
                  onChange={(e) => setCert({ ...cert, trademarkNameAr: e.target.value })}
                  maxLength={60}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-right text-lg font-amiri focus:outline-none focus:border-amber-500 text-amber-100"
                  placeholder="مثال: شركة النهرين لتقنية المعلومات"
                />
              </div>

              {/* Logo customization panel */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
                <span className="block text-slate-400 text-xs font-bold mb-2 uppercase tracking-wider font-mono">
                  Trademark Brand Logo Icon
                </span>
                
                <div className="flex gap-4 items-center">
                  {/* Miniature Logo Preview */}
                  <div className="w-16 h-16 bg-slate-900 rounded-lg flex items-center justify-center border border-slate-800 relative z-10 shrink-0">
                    {cert.trademarkLogoUrl === 'uploaded' && uploadedLogo ? (
                      <img src={uploadedLogo} alt="Uploaded logo preview" className="w-12 h-12 object-contain" referrerPolicy="no-referrer" />
                    ) : (
                      <LogoPresetRenderer placeholderType={cert.trademarkLogoUrl} name={cert.trademarkNameEn} />
                    )}
                  </div>

                  <div className="flex-1 space-y-2">
                    {/* Presets selector buttons */}
                    <div className="grid grid-cols-2 gap-1.5">
                      <button 
                        onClick={() => setCert({ ...cert, trademarkLogoUrl: 'telecom' })}
                        className={`px-2 py-1 text-[10px] rounded border text-left transition ${cert.trademarkLogoUrl === 'telecom' ? 'bg-amber-500/10 border-amber-500/40 text-amber-200' : 'bg-slate-900 border-slate-850 hover:bg-slate-800'}`}
                      >
                        📡 Telecom Node
                      </button>
                      <button 
                        onClick={() => setCert({ ...cert, trademarkLogoUrl: 'coffee' })}
                        className={`px-2 py-1 text-[10px] rounded border text-left transition ${cert.trademarkLogoUrl === 'coffee' ? 'bg-amber-500/10 border-amber-500/40 text-amber-200' : 'bg-slate-900 border-slate-850 hover:bg-slate-800'}`}
                      >
                        ☕ Babylon Coffee
                      </button>
                      <button 
                        onClick={() => setCert({ ...cert, trademarkLogoUrl: 'shield' })}
                        className={`px-2 py-1 text-[10px] rounded border text-left transition ${cert.trademarkLogoUrl === 'shield' ? 'bg-amber-500/10 border-amber-500/40 text-amber-200' : 'bg-slate-900 border-slate-850 hover:bg-slate-800'}`}
                      >
                        🛡️ National Shield
                      </button>
                      <button 
                        onClick={() => setCert({ ...cert, trademarkLogoUrl: 'gold-emblem' })}
                        className={`px-2 py-1 text-[10px] rounded border text-left transition ${cert.trademarkLogoUrl === 'gold-emblem' ? 'bg-amber-500/10 border-amber-500/40 text-amber-200' : 'bg-slate-900 border-slate-850 hover:bg-slate-800'}`}
                      >
                        ⚜️ Monogram Seal
                      </button>
                    </div>

                    {/* Image file uploader */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="p-1 px-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded font-mono text-[10px] font-semibold text-slate-300 flex items-center gap-1 transition"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Upload Custom PNG</span>
                      </button>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleLogoUpload} 
                        accept="image/*" 
                        className="hidden" 
                      />
                      {cert.trademarkLogoUrl === 'uploaded' && (
                        <span className="text-[10px] font-mono text-emerald-500 truncate max-w-[120px]">
                          ✓ {cert.trademarkLogoName || "Loaded"}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Nice classification selector & drop */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 text-xs font-bold mb-1 uppercase tracking-wider font-mono">
                    Nice Class & pres.
                  </label>
                  <select 
                    value={cert.niceClass} 
                    onChange={(e) => handleNiceClassSelector(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-amber-500 text-slate-100 font-mono"
                  >
                    {NICE_CLASSES.map((nc) => (
                      <option key={nc.classNumber} value={nc.classNumber}>
                        Class {nc.classNumber} - {nc.titleEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 text-xs font-bold mb-1 uppercase tracking-wider font-mono">
                    Trademark Type
                  </label>
                  <select 
                    value={cert.trademarkType}
                    onChange={(e) => {
                      const type = e.target.value as any;
                      let typeAr = "مشتركة";
                      if (type === 'Word') typeAr = "لفظية";
                      else if (type === 'Device') typeAr = "تصويرية / رسمية";
                      else if (type === 'Three-Dimensional') typeAr = "مجسمة ثلاثية الأبعاد";
                      setCert({ ...cert, trademarkType: type, trademarkTypeAr: typeAr });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-amber-500 text-slate-100 font-mono"
                  >
                    <option value="Word">Word Label (لفظية)</option>
                    <option value="Device">Device Logo (تصويرية)</option>
                    <option value="Composite">Composite Label (مشتركة)</option>
                    <option value="Three-Dimensional">Three-Dimensional立体</option>
                  </select>
                </div>
              </div>

              {/* Goods & Services text boxes */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-3">
                <div>
                  <label className="block text-slate-500 text-[10px] font-bold mb-1 uppercase tracking-wider font-mono">
                    Goods & Services (English description)
                  </label>
                  <textarea 
                    value={cert.goodsDescriptionEn} 
                    onChange={(e) => setCert({ ...cert, goodsDescriptionEn: e.target.value })}
                    rows={2}
                    className="w-full bg-slate-900 border border-slate-800/60 rounded p-2 text-xs focus:outline-none focus:border-amber-500 text-slate-200"
                    placeholder="Enter Class specifications..."
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[10px] font-bold mb-1 text-right uppercase tracking-wider font-mono">
                    وصف السلع والخدمات بالعربي
                  </label>
                  <textarea 
                    value={cert.goodsDescriptionAr} 
                    onChange={(e) => setCert({ ...cert, goodsDescriptionAr: e.target.value })}
                    rows={2}
                    className="w-full bg-slate-900 border border-slate-800/60 rounded p-2 text-sm font-amiri text-right focus:outline-none focus:border-amber-500 text-amber-100"
                    placeholder="أدخل حدود الحماية للعلامة المصنفة باللغة العربية..."
                  />
                </div>
              </div>

              {/* Proprietor information */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-3">
                <span className="block text-slate-400 text-xs font-bold uppercase tracking-wider font-mono mb-2">
                  Proprietor Legal Entity (المالك)
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-500 text-[10px] font-mono block">Owner name (EN)</label>
                    <input 
                      type="text" 
                      value={cert.ownerNameEn}
                      onChange={(e) => setCert({ ...cert, ownerNameEn: e.target.value.toUpperCase() })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs focus:outline-none focus:border-amber-500 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 text-[10px] font-mono block text-right">المالك بالعربي</label>
                    <input 
                      type="text" 
                      value={cert.ownerNameAr}
                      onChange={(e) => setCert({ ...cert, ownerNameAr: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-sm font-amiri text-right focus:outline-none focus:border-amber-500 text-amber-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-500 text-[10px] font-mono block">Nationality (EN)</label>
                    <input 
                      type="text" 
                      value={cert.ownerNationalityEn}
                      onChange={(e) => setCert({ ...cert, ownerNationalityEn: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 text-[10px] font-mono block text-right">الجنسية</label>
                    <input 
                      type="text" 
                      value={cert.ownerNationalityAr}
                      onChange={(e) => setCert({ ...cert, ownerNationalityAr: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-sm font-amiri text-right focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-500 text-[10px] font-mono block">Address (EN)</label>
                  <input 
                    type="text" 
                    value={cert.ownerAddressEn}
                    onChange={(e) => setCert({ ...cert, ownerAddressEn: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs focus:outline-none focus:border-amber-500 text-slate-200"
                  />
                </div>
                <div>
                  <label className="text-slate-500 text-[10px] font-mono block text-right">عنوان مقر المالك بالتفصيل</label>
                  <input 
                    type="text" 
                    value={cert.ownerAddressAr}
                    onChange={(e) => setCert({ ...cert, ownerAddressAr: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-sm font-amiri text-right focus:outline-none focus:border-amber-500 text-slate-200"
                  />
                </div>
              </div>

              {/* Chronology Registrations & Journal Numbers */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 grid grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-500 text-[10px] font-mono block">Application date</label>
                  <input 
                    type="date" 
                    value={cert.applicationDate}
                    onChange={(e) => handleDateChange('applicationDate', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-500 text-[10px] font-mono block">Registration date</label>
                  <input 
                    type="date" 
                    value={cert.registrationDate}
                    onChange={(e) => handleDateChange('registrationDate', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-500 text-[10px] font-mono block font-mono">Journal Number (الجريدة)</label>
                  <input 
                    type="text" 
                    value={cert.journalNumber} 
                    onChange={(e) => setCert({ ...cert, journalNumber: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-100 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-500 text-[10px] font-mono block font-mono">Page Number (الصفحة)</label>
                  <input 
                    type="text" 
                    value={cert.journalPageNumber} 
                    onChange={(e) => setCert({ ...cert, journalPageNumber: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-100 font-mono"
                  />
                </div>
              </div>

              {/* Aesthetic Security Toggles */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2">
                <span className="block text-slate-400 text-xs font-bold uppercase tracking-wider font-mono">
                  Certificate Visual Security Ornaments
                </span>
                
                <div className="flex flex-wrap gap-4 pt-1">
                  <label className="flex items-center gap-2 text-xs select-none cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={cert.enableGoldSeal}
                      onChange={(e) => setCert({ ...cert, enableGoldSeal: e.target.checked })}
                      className="border-slate-800 rounded text-amber-500" 
                    />
                    <span>Golden Imperial Seal</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs select-none cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={cert.enableRepublicRibbon}
                      onChange={(e) => setCert({ ...cert, enableRepublicRibbon: e.target.checked })}
                      className="border-slate-800 rounded text-emerald-500" 
                    />
                    <span>National Tricolor Ribbon</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs select-none cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={cert.enableGuillocheBg}
                      onChange={(e) => setCert({ ...cert, enableGuillocheBg: e.target.checked })}
                      className="border-slate-800 rounded text-amber-500" 
                    />
                    <span>Guilloche Security Watermark</span>
                  </label>
                </div>
              </div>

              {/* Save & Register to Live Database */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={saveActiveCertToDatabase}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-550 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all duration-250 shadow-lg shadow-emerald-900/10 border border-emerald-500/30 cursor-pointer text-center"
                >
                  <Save className="w-4 h-4 shrink-0" />
                  <span>تسجيل وحفظ في السجل الوطني العام / REGISTER IN LEDGER</span>
                </button>
                {saveFeedback && (
                  <p className="text-[11px] text-emerald-400 font-medium font-mono text-center mt-2.5 animate-pulse">
                    ✓ {saveFeedback}
                  </p>
                )}
              </div>

            </div>
          </div>
        </section>

        {/* Right Preview Column (7cols) */}
        <main className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Workdesk Control Tab Switcher - Hidden during active print */}
          <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 no-print shadow-lg">
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-850/80 w-full sm:w-auto overflow-x-auto">
              <button 
                onClick={() => setActiveTab('preview')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 flex-1 sm:flex-initial whitespace-nowrap ${activeTab === 'preview' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Iraq Certificate (A4)</span>
              </button>
              <button 
                onClick={() => setActiveTab('portal')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 flex-1 sm:flex-initial whitespace-nowrap ${activeTab === 'portal' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Government Portal Lookup</span>
              </button>
              <button 
                onClick={() => setActiveTab('database')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 flex-1 sm:flex-initial whitespace-nowrap ${activeTab === 'database' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
              >
                <Database className="w-3.5 h-3.5" />
                <span>Online Database (JSON)</span>
              </button>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {/* Copy QR Code URL */}
              <button 
                onClick={copyShareLink}
                className="p-2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                title="Copy cryptographically-linked verification URL to share"
              >
                <Share2 className="w-4 h-4 text-amber-400" />
                <span>{copiedUrl ? 'Copied Link!' : 'Share Cert'}</span>
              </button>

              <button 
                onClick={triggerPrint}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950/40 transition"
              >
                <Printer className="w-4 h-4" />
                <span>Print Certificate</span>
              </button>
            </div>
          </div>

          {/* Quick Real-Time Language Filter & Download Settings */}
          {activeTab === 'preview' && (
            <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 no-print shadow-lg animate-fade-in">
              <div className="flex items-center gap-2 text-slate-300 font-mono text-xs">
                <Globe className="w-4 h-4 text-amber-500 animate-pulse" />
                <span className="font-bold tracking-wider">PRINT PREVIEW LANGUAGE:</span>
              </div>
              <div className="flex bg-slate-950 border border-slate-850 p-1 rounded-xl w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setCertLanguage('bilingual')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition flex-1 sm:flex-initial ${certLanguage === 'bilingual' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  Bilingual (العراق)
                </button>
                <button
                  type="button"
                  onClick={() => setCertLanguage('english')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition flex-1 sm:flex-initial ${certLanguage === 'english' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  English Only
                </button>
                <button
                  type="button"
                  onClick={() => setCertLanguage('arabic')}
                  className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition flex-1 sm:flex-initial ${certLanguage === 'arabic' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  العربية فقط
                </button>
              </div>
            </div>
          )}

          <AnimatePresence mode="wait">
            {activeTab === 'preview' ? (
              
              /* HIGH RESOLUTION CERTIFICATE CONTAINER WORKPANE */
              <motion.div 
                key="preview-pane"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="flex justify-center"
              >
                
                {/* Physical Certificate Canvas Representation */}
                <div id="republican-certificate" className="certificate-print-area vintage-ivory w-[800px] aspect-[1/1.414] border-[14px] border-[#a68d55] bg-white text-slate-900 shadow-2xl relative p-8 select-none flex flex-col justify-between overflow-hidden">
                  
                  {/* Guilloche security pattern backdrop layer */}
                  {cert.enableGuillocheBg && (
                    <div className="absolute inset-2 border-2 border-dashed border-[#bda26b] opacity-30 pointer-events-none bg-repeat guilloche-pattern" />
                  )}

                  {/* Elegant Golden inner frame */}
                  <div className="absolute inset-1.5 border border-[#bfa56f] pointer-events-none" />
                  <div className="absolute inset-4 border border-[#e2d6bc] opacity-50 pointer-events-none" />

                  {/* High Quality Traditional Corners */}
                  <div className="absolute top-4 left-4 w-12 h-12 border-t-4 border-l-4 border-amber-600/65 rounded-tl-lg pointer-events-none" />
                  <div className="absolute top-4 right-4 w-12 h-12 border-t-4 border-r-4 border-amber-600/65 rounded-tr-lg pointer-events-none" />
                  <div className="absolute bottom-4 left-4 w-12 h-12 border-b-4 border-l-4 border-amber-600/65 rounded-bl-lg pointer-events-none" />
                  <div className="absolute bottom-4 right-4 w-12 h-12 border-b-4 border-r-4 border-amber-600/65 rounded-br-lg pointer-events-none" />

                  {/* REPUBLIC OF IRAQ FLAG CORNER RIBBON ACCENT */}
                  {cert.enableRepublicRibbon && (
                    <div className="absolute -top-1 right-[112px] w-14 h-16 pointer-events-none overflow-hidden z-10 flex flex-col select-none">
                      <div className="flex h-1/3">
                        <div className="w-1/3 bg-[#b11c1c] h-full" /> {/* Red */}
                        <div className="w-1/3 bg-[#ffffff] h-full flex items-center justify-center font-bold text-[4px] leading-none text-[#1c6627]">الله</div>
                        <div className="w-1/3 bg-[#2c3e50] h-full" /> {/* Black */}
                      </div>
                      <div className="flex h-1/3">
                        <div className="w-1/3 bg-[#b11c1c] h-full" />
                        <div className="w-1/3 bg-[#ffffff] h-full flex items-center justify-center font-bold text-[4px] leading-none text-[#1c6627]">أكبر</div>
                        <div className="w-1/3 bg-[#2c3e50] h-full" />
                      </div>
                    </div>
                  )}

                  {/* CENTRAL GIANT EAGLE WATERMARK BACKGROUND PORTRAIT */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.035] pointer-events-none">
                    <IraqiEmblemSVG className="w-[420px] h-[420px]" />
                  </div>

                  {/* 1. OFFICIAL SYMMETRIC BILINGUAL HEADER */}
                  <div className="grid grid-cols-12 gap-2 items-center pb-4 border-b-2 border-amber-800/10 relative z-10 w-full">
                    
                    {/* Left: English administrative block */}
                    {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                      <div className={`${certLanguage === 'english' ? 'col-span-12 text-center' : 'col-span-5 text-left'} space-y-0.5`}>
                        <h3 className="text-[11px] font-bold tracking-tight font-sans text-stone-800">REPUBLIC OF IRAQ</h3>
                        <p className="text-[9px] font-medium text-stone-600">Ministry of Industry & Minerals</p>
                        <p className="text-[8px] text-stone-500 leading-tight">Industrial Development & Org. Directorate</p>
                        <p className="text-[8px] text-stone-500 font-semibold border-t border-amber-800/10 pt-0.5">Intellectual Property & Trademark Office</p>
                      </div>
                    )}

                    {/* Center: Miniature official coat of arms */}
                    {certLanguage === 'bilingual' && (
                      <div className="col-span-2 flex justify-center">
                        <IraqiEmblemSVG className="w-[52px] h-[52px] text-stone-700 animate-pulse" />
                      </div>
                    )}

                    {/* Right: Arabic Administrative block */}
                    {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                      <div className={`${certLanguage === 'arabic' ? 'col-span-12 text-center' : 'col-span-5 text-right'} space-y-0.5`}>
                        <h3 className="text-sm font-bold font-amiri text-stone-800">جمهورية العراق</h3>
                        <p className="text-[10px] font-semibold font-amiri text-stone-700">وزارة الصناعة والمعادن</p>
                        <p className="text-[9px] font-amiri text-stone-600 leading-tight">مديرية التنمية الصناعية والتنظيم</p>
                        <p className="text-[9px] font-amiri font-bold text-stone-600 border-t border-amber-800/10 pt-0.5">مكتب الملكية الفكرية وتصنيف العلامات</p>
                      </div>
                    )}

                  </div>

                  {/* 2. EXQUISITE CERTIFICATE TITLE */}
                  <div className="text-center py-4 relative z-10 space-y-1">
                    {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                      <h2 className="text-lg font-extrabold tracking-widest font-serif-eng text-amber-900 border-b border-amber-600/15 pb-1 max-w-sm mx-auto">
                        CERTIFICATE OF REGISTRATION
                      </h2>
                    )}
                    
                    {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                      <h2 className="text-2xl font-bold font-amiri text-amber-950 tracking-wide">
                        شهـادة تسجيـل علامـة تجاريـة
                      </h2>
                    )}
                    
                    <div className="flex justify-center items-center gap-1.5 text-stone-500 text-[9px] font-mono">
                      {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                        <span>No. {cert.registryNumber}</span>
                      )}
                      {certLanguage === 'bilingual' && <span>•</span>}
                      {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                        <span className="font-amiri font-bold">رقم التسجيل: {cert.registryNumber}</span>
                      )}
                    </div>
                  </div>

                  {/* 3. CORE SUBSTANTIVE DATA BOX */}
                  <div className="flex-1 grid grid-cols-12 gap-4 items-stretch relative z-10 my-1">
                    
                    {/* Left & Middle: Detailed registration tables */}
                    <div className="col-span-9 space-y-3.5 pr-2">
                      
                      {/* Bilingual owner announcement */}
                      <div className="bg-amber-50/20 border border-amber-600/10 rounded-xl p-3 space-y-1.5">
                        <div className="flex justify-between text-[9px] font-mono text-stone-500 border-b border-stone-200 pb-0.5">
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <span>PROPRIETOR REGISTERED OWNER</span>
                          )}
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <span>مالك العلامة التجاريـة المقيد بالسجلات</span>
                          )}
                        </div>
                        
                        <div className="flex justify-between items-start gap-1">
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <p className={`text-xs font-bold text-stone-800 font-mono tracking-tight ${certLanguage === 'english' ? 'w-full text-left' : 'max-w-[50%]'}`}>
                              {cert.ownerNameEn}
                            </p>
                          )}
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <p className={`text-md font-bold font-amiri text-stone-900 leading-snug ${certLanguage === 'arabic' ? 'w-full text-right' : 'max-w-[50%] text-right'}`}>
                              {cert.ownerNameAr}
                            </p>
                          )}
                        </div>

                        <div className="flex justify-between pt-1 border-t border-stone-100 text-[10px]">
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <span className="text-stone-500 font-mono text-[8px]">{cert.ownerNationalityEn}</span>
                          )}
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <span className="font-amiri font-bold text-stone-700">{cert.ownerNationalityAr}</span>
                          )}
                        </div>

                        <div className="text-[10px] text-stone-500 flex justify-between gap-2 pt-0.5">
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <span className="font-mono text-[8px] truncate max-w-[190px]">{cert.ownerAddressEn}</span>
                          )}
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <span className="font-amiri text-[9px] truncate max-w-[190px] text-right">{cert.ownerAddressAr}</span>
                          )}
                        </div>
                      </div>

                      {/* Biligual Nice Class declaration */}
                      <div className="grid grid-cols-12 gap-1 bg-amber-50/20 border border-amber-600/10 rounded-xl p-3">
                        <div className="col-span-3 flex flex-col justify-center items-center border-r border-[#eddcb8] pr-2">
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <span className="text-[9px] font-mono text-stone-500">CLASS</span>
                          )}
                          <span className="text-2xl font-extrabold text-amber-900 font-mono">{cert.niceClass}</span>
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <span className="text-[9px] font-amiri font-bold text-stone-600">الفئـة</span>
                          )}
                        </div>
                        
                        <div className="col-span-9 pl-3 flex flex-col justify-center">
                          <div className="flex justify-between text-[9px] font-mono text-stone-500">
                            {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                              <span>NICE STANDARD SPECIFICATIONS</span>
                            )}
                            {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                              <span>مدى سلع وخدمات الفئة المقيدة</span>
                            )}
                          </div>
                          
                          {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                            <p className="text-[10.5px] font-sans text-stone-800 leading-tight truncate-multiline mt-1 h-8 overflow-hidden" title={cert.goodsDescriptionEn}>
                              {cert.goodsDescriptionEn}
                            </p>
                          )}
                          
                          {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                            <p className="text-[11px] font-amiri text-stone-800 text-right leading-tight truncate-multiline mt-1 h-8 overflow-hidden border-t border-stone-100 pt-0.5" title={cert.goodsDescriptionAr}>
                              {cert.goodsDescriptionAr}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Logistical timeline dates */}
                      <div className="bg-stone-50/60 border border-stone-200/80 rounded-xl p-3">
                        <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                          <div className={`${certLanguage === 'bilingual' ? 'border-r border-stone-200/60' : certLanguage === 'english' ? 'border-r border-stone-200/60' : 'border-l border-stone-200/60'}`}>
                            {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                              <span className="text-stone-500 block font-mono text-[8px]">APPLICATION DATE</span>
                            )}
                            <span className="text-xs font-bold font-mono text-stone-800">{cert.applicationDate}</span>
                            {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                              <span className="text-[9px] font-amiri block text-stone-600">تاريخ تقديم الطلب</span>
                            )}
                          </div>
                          <div className={`${certLanguage === 'bilingual' ? 'border-r border-stone-200/60' : certLanguage === 'english' ? 'border-r border-stone-200/60' : ''}`}>
                            {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                              <span className="text-stone-500 block font-mono text-[8px]">REGISTRATION DATE</span>
                            )}
                            <span className="text-xs font-bold font-mono text-stone-800">{cert.registrationDate}</span>
                            {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                              <span className="text-[9px] font-amiri block text-stone-600">تاريخ النشر والتسجيل</span>
                            )}
                          </div>
                          <div>
                            {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                              <span className="text-stone-500 block font-mono text-[8px]">VALID EXPIRY DATE</span>
                            )}
                            <span className="text-xs font-bold font-mono text-amber-800">{cert.expiryDate}</span>
                            {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                              <span className="text-[9px] font-amiri block text-amber-700 font-bold">تاريخ انتهاء الحماية</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Registration and journal metrics */}
                      <div className="flex justify-between bg-stone-50/40 p-2 rounded-lg border border-stone-200/60 text-[9px] font-mono text-stone-600">
                        <div className="flex gap-4">
                          <span>App No: {cert.applicationNumber}</span>
                          <span>•</span>
                          <span>Official Journal No: {cert.journalNumber}</span>
                        </div>
                        <div>
                          <span>Ledger Page: {cert.journalPageNumber}</span>
                        </div>
                      </div>

                    </div>

                    {/* Right column: Logo visual display & Official Scan QR Verification code */}
                    <div className="col-span-3 flex flex-col justify-between items-center pl-2 border-l border-amber-800/10">
                      
                      {/* Active Trademark custom logo design box */}
                      <div className="space-y-1 text-center w-full mt-2">
                        <span className="text-[8px] font-mono text-stone-400 block tracking-normal uppercase">Trademark Emblem</span>
                        <div className="w-24 h-24 bg-stone-50 rounded-lg flex items-center justify-center p-2 mx-auto border border-stone-200/80 shadow-inner relative overflow-hidden z-10">
                          {cert.trademarkLogoUrl === 'uploaded' && uploadedLogo ? (
                            <img src={uploadedLogo} alt="Uploaded logo" className="w-20 h-20 object-contain" referrerPolicy="no-referrer" />
                          ) : (
                            <LogoPresetRenderer placeholderType={cert.trademarkLogoUrl} name={cert.trademarkNameEn} />
                          )}
                        </div>
                        {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                          <span className="text-[10px] font-extrabold text-stone-800 font-mono uppercase tracking-tight block truncate max-w-full">
                            {cert.trademarkNameEn}
                          </span>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                          <span className="text-xs font-bold text-amber-900 font-amiri block truncate max-w-full">
                            {cert.trademarkNameAr}
                          </span>
                        )}
                      </div>

                      {/* CRYPTOGRAPHIC VERIFICATION WORKING QR CODE */}
                      <div className="space-y-1 text-center w-full pb-2">
                        
                        {/* Realistic functional link */}
                        <div className="w-24 h-24 bg-white p-1.5 rounded-lg mx-auto border border-stone-200 flex items-center justify-center shadow-sm relative group z-10">
                          <QRCodeSVG 
                            value={getVerificationUrl()}
                            size={84}
                            level="M"
                            bgColor="#ffffff"
                            fgColor="#042F1A" // Official dark green Iraqi color code
                          />
                        </div>
                        {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                          <span className="text-[7.5px] font-bold text-stone-400 font-mono uppercase block tracking-tighter">
                            Scan to Verify Registry
                          </span>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                          <span className="text-[8px] font-amiri font-semibold text-stone-500 block leading-none">
                            امسح للتحقق من الصلاحية
                          </span>
                        )}
                      </div>

                    </div>
                  </div>

                  {/* 4. FOOTER SIGNATURES & OFFICIAL SEALS */}
                  <div className="border-t border-stone-200/80 pt-4 flex items-center justify-between relative z-10 h-28">
                    
                    {/* Left: Administrative details & secure verification checksum */}
                    <div className="text-[9px] text-stone-500 space-y-1 text-left w-1/2">
                      <p className="font-mono">IP Secure ID: {cert.registryNumber}</p>
                      <p className="font-mono text-[7.5px] text-stone-400 truncate max-w-[220px]">SHA-Key: {cert.securityHash}</p>
                      <div className="flex items-center gap-1.5 text-stone-400 mt-2">
                        <Shield className="w-3.5 h-3.5 text-emerald-700" />
                        <span className="text-[7.5px] uppercase tracking-normal font-mono font-bold">Authenticated Authority</span>
                      </div>
                    </div>

                    {/* Right: Signature of the Registrar & Official Department wet stamp */}
                    <div className="w-1/2 text-right relative flex flex-col justify-end items-end h-full">
                      
                      {/* Department Ink Stamp - overlapped organically inside signature box */}
                      {(cert.registrarSignatureOption === 'stamp-only' || cert.registrarSignatureOption === 'wet-ink') && (
                        <div className="absolute top-1 right-2 w-20 h-20 rounded-full border-4 border-emerald-700/35 border-double flex items-center justify-center text-center opacity-70 rotate-[12deg] pointer-events-none select-none">
                          <div className="absolute inset-1 border border-emerald-700/25 rounded-full flex flex-col justify-center items-center">
                            <span className="text-[6px] font-bold text-emerald-800 uppercase font-mono leading-none">Republic of Iraq</span>
                            <span className="text-[8px] font-amiri font-bold text-emerald-800 leading-none my-0.5">مسجل العلامات</span>
                            <span className="text-[6px] text-emerald-800 uppercase font-mono leading-none">Baghdad Patent</span>
                          </div>
                        </div>
                      )}

                      {/* Registrar hand signature */}
                      {cert.registrarSignatureOption === 'wet-ink' && (
                        <div className="absolute bottom-6 right-6 w-28 h-10 pointer-events-none select-none z-20">
                          {/* Dynamic calligraphy vector signature */}
                          <svg className="w-full h-full text-blue-800/80 saturate-150 rotate-[-4deg]" viewBox="0 0 100 40">
                            <path d="M10 25 C30 10 40 35 60 15 C75 -5 85 30 95 10 M40 28 L75 28 M20 20 Q50 5 80 32" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                        </div>
                      )}

                      <div className="space-y-0.5 text-right relative z-10 mt-auto">
                        {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                          <p className="text-[10px] font-bold font-amiri text-stone-800">{cert.registrarNameAr}</p>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                          <p className="text-[9px] font-bold text-stone-800 leading-tight font-sans tracking-tight">{cert.registrarNameEn}</p>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'arabic') && (
                          <p className="text-[8px] text-stone-500 font-amiri leading-none">{cert.registrarTitleAr}</p>
                        )}
                        {(certLanguage === 'bilingual' || certLanguage === 'english') && (
                          <p className="text-[7.5px] text-stone-400 tracking-tight leading-none">{cert.registrarTitleEn}</p>
                        )}
                      </div>

                    </div>
                  </div>

                </div>
              </motion.div>
            ) : activeTab === 'portal' ? (
              
              /* INTERACTIVE SCANNED PORTAL OR VERIFICATION INTERMEDIATE VIEW */
              <motion.div 
                key="portal-pane"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 text-slate-200"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-center text-emerald-400 shrink-0">
                      <Database className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-slate-100 font-bold text-sm uppercase tracking-wider font-mono flex items-center gap-2">
                        <span>Registry Ledger Database Search</span>
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded-full font-sans capitalize font-normal">Active Server Link</span>
                      </h3>
                      <p className="text-xs text-slate-400 font-amiri text-right sm:text-left mt-0.5" dir="rtl">
                        بوابة الاستعلام الوطنية عن العلامات التجارية المسجلة بجمهورية العراق
                      </p>
                    </div>
                  </div>
                </div>

                {/* Database Search & copy area */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                  {/* Left panel: Search Controls & results (col-span-7) */}
                  <div className="xl:col-span-7 space-y-4">
                    <div className="bg-slate-950 p-5 rounded-xl border border-slate-850 space-y-3">
                      <label className="block text-xs font-mono font-bold text-slate-300 uppercase tracking-widest">
                        Enter Registry Number, Brand Name, or Paste share link URL:
                      </label>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <input 
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleDatabaseSearch(searchQuery);
                              }
                            }}
                            placeholder="e.g. 148392, BABYLON, or paste copied link..."
                            className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-22 text-xs focus:outline-none focus:border-amber-500 text-slate-200 font-mono"
                          />
                          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                        </div>
                        <button 
                          onClick={() => handleDatabaseSearch(searchQuery)}
                          disabled={isSearching}
                          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-600/50 text-slate-950 font-bold text-xs rounded-lg transition duration-150 flex items-center gap-1.5 shrink-0 select-none"
                        >
                          {isSearching ? (
                            <>
                              <RefreshCw className="w-3 h-3 animate-spin" />
                              <span>Searching...</span>
                            </>
                          ) : (
                            <>
                              <Search className="w-3 h-3" />
                              <span>Search Ledger</span>
                            </>
                          )}
                        </button>
                      </div>

                      {searchError && (
                        <div className="p-3 bg-red-950/40 border border-red-500/20 rounded-lg text-red-100 text-xs flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                          <span>{searchError}</span>
                        </div>
                      )}

                      <p className="text-[10.5px] text-slate-400 font-mono leading-relaxed">
                        ⚡ How to test pasting: click <strong className="text-amber-400">"Copy Search Link"</strong> from any record on the right, or click <strong className="text-amber-400">"Share Cert"</strong> at the top, then paste the full link into this search box to simulate verifying.
                      </p>
                    </div>

                    {/* Search results rendering panel */}
                    <AnimatePresence mode="wait">
                      {searchResult ? (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="bg-slate-950 border-2 border-emerald-500/30 rounded-xl p-5 space-y-4 shadow-lg relative overflow-hidden"
                        >
                          {/* Glow watermark */}
                          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
                          <div className="absolute top-3 right-3 bg-emerald-950/85 text-emerald-400 border border-emerald-550/30 font-mono text-[9px] font-bold uppercase tracking-wider py-1 px-2.5 rounded-full flex items-center gap-1">
                            <Check className="w-3 h-3" />
                            <span>Verified Match Found</span>
                          </div>

                          <div className="flex gap-4 items-start pt-2">
                            <div className="w-14 h-14 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-center p-1 relative z-10 shrink-0">
                              <LogoPresetRenderer placeholderType={searchResult.trademarkLogoUrl} name={searchResult.trademarkNameEn} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="text-sm font-bold text-white font-mono uppercase tracking-tight truncate">
                                {searchResult.trademarkNameEn}
                              </h4>
                              <p className="text-base font-bold font-amiri text-amber-200 mt-0.5 truncate leading-none">
                                {searchResult.trademarkNameAr}
                              </p>
                              <p className="text-[10px] text-slate-400 mt-1 font-mono">
                                Registered to: <span className="text-slate-200">{searchResult.ownerNameEn}</span>
                              </p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-slate-900/40 p-3 rounded-lg border border-slate-850 font-mono text-[10px] text-slate-400">
                            <div>
                              <span className="block text-slate-500 text-[8px] uppercase font-bold">Registry No.</span>
                              <span className="text-amber-400 font-bold">{searchResult.registryNumber}</span>
                            </div>
                            <div>
                              <span className="block text-slate-500 text-[8px] uppercase font-bold">Nice Class</span>
                              <span className="text-slate-200 font-bold">Class {searchResult.niceClass}</span>
                            </div>
                            <div>
                              <span className="block text-slate-500 text-[8px] uppercase font-bold">Expiry Date</span>
                              <span className="text-slate-200">{searchResult.expiryDate}</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2 pt-2">
                            <button 
                              onClick={() => {
                                setScannedData(searchResult);
                                setVerificationMode(true);
                              }}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 transition shadow-lg shadow-emerald-950/40"
                            >
                              <Shield className="w-3.5 h-3.5" />
                              <span>View Verified Certificate</span>
                            </button>
                            <button 
                              onClick={() => {
                                setCert(searchResult);
                                setSearchResult(null);
                                setSearchQuery('');
                                setActiveTab('preview');
                              }}
                              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-705 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                            >
                              <Edit className="w-3.5 h-3.5 text-amber-500" />
                              <span>Load into Creator Studio</span>
                            </button>
                            <button 
                              onClick={() => setSearchResult(null)}
                              className="px-2.5 py-2 hover:bg-slate-850 text-slate-500 hover:text-slate-350 text-xs font-mono transition"
                            >
                              Dismiss
                            </button>
                          </div>
                        </motion.div>
                      ) : (
                        <div className="border border-dashed border-slate-800 rounded-xl p-8 text-center bg-slate-950/20 font-mono text-xs text-slate-500">
                          <Database className="w-8 h-8 text-slate-700 mx-auto mb-2 opacity-60 animate-pulse" />
                          <p>Waiting for dynamic lookup queries...</p>
                          <p className="text-[10px] mt-1 text-slate-600">Select any record on the right to auto-query, or paste a live URL link above.</p>
                        </div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Right panel: Live Registry Databases / Recent Records (col-span-5) */}
                  <div className="xl:col-span-12 xl:order-last min-w-0" style={{ order: 99 }}>
                    <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3.5">
                      <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 pb-2 border-b border-slate-850">
                        <FileText className="w-3.5 h-3.5 text-amber-500" />
                        <span>Live Database Registry Records</span>
                      </h4>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {/* 1. Preset 1 */}
                        <div className="p-3 bg-slate-900 hover:bg-slate-850/60 transition border border-slate-850 rounded-lg flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className="font-mono text-xs font-bold text-slate-100 uppercase tracking-tight truncate">Iraq Cell</span>
                                <span className="text-[8px] bg-emerald-900/50 text-emerald-400 px-1 py-0.2 rounded font-mono uppercase shrink-0">Active</span>
                              </div>
                              <span className="font-mono text-[9px] text-amber-500 font-bold bg-amber-500/10 px-2 py-0.5 rounded shrink-0">ID: 148392</span>
                            </div>
                            <p className="font-amiri text-xs text-slate-400 leading-none">العراق للأنظمة الخلوية</p>
                          </div>

                          <div className="flex justify-between items-center gap-3 pt-2.5 mt-3 border-t border-slate-850 text-[10px]">
                            <button 
                              onClick={() => {
                                const url = getCompressedUrl(MOCK_CERTIFICATE_PRESETS.iraqCell);
                                navigator.clipboard.writeText(url).then(() => {
                                  setCopiedRecentId('preset-1');
                                  setTimeout(() => setCopiedRecentId(null), 2000);
                                });
                              }}
                              className="text-slate-400 hover:text-amber-400 font-mono flex items-center gap-1 transition"
                            >
                              <Copy className="w-3 h-3 text-slate-500" />
                              <span>{copiedRecentId === 'preset-1' ? 'Copied Link!' : 'Copy Search Link'}</span>
                            </button>
                            <button 
                              onClick={() => {
                                setSearchQuery(MOCK_CERTIFICATE_PRESETS.iraqCell.registryNumber);
                                handleDatabaseSearch(MOCK_CERTIFICATE_PRESETS.iraqCell.registryNumber);
                              }}
                              className="text-amber-500 hover:text-amber-400 font-semibold font-mono flex items-center gap-1 transition"
                            >
                              <span>Query Ledger</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        </div>

                        {/* 2. Preset 2 */}
                        <div className="p-3 bg-slate-900 hover:bg-slate-850/60 transition border border-slate-850 rounded-lg flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className="font-mono text-xs font-bold text-slate-100 uppercase tracking-tight truncate">Babylon Coffee</span>
                                <span className="text-[8px] bg-emerald-900/50 text-emerald-400 px-1 py-0.2 rounded font-mono uppercase shrink-0">Active</span>
                              </div>
                              <span className="font-mono text-[9px] text-amber-500 font-bold bg-amber-500/10 px-2 py-0.5 rounded shrink-0">ID: 159403</span>
                            </div>
                            <p className="font-amiri text-xs text-slate-400 leading-none">محامص ومقاهي بابل</p>
                          </div>

                          <div className="flex justify-between items-center gap-3 pt-2.5 mt-3 border-t border-slate-850 text-[10px]">
                            <button 
                              onClick={() => {
                                const url = getCompressedUrl(MOCK_CERTIFICATE_PRESETS.tigrisCoffee);
                                navigator.clipboard.writeText(url).then(() => {
                                  setCopiedRecentId('preset-2');
                                  setTimeout(() => setCopiedRecentId(null), 2000);
                                });
                              }}
                              className="text-slate-400 hover:text-amber-400 font-mono flex items-center gap-1 transition"
                            >
                              <Copy className="w-3 h-3 text-slate-500" />
                              <span>{copiedRecentId === 'preset-2' ? 'Copied Link!' : 'Copy Search Link'}</span>
                            </button>
                            <button 
                              onClick={() => {
                                setSearchQuery(MOCK_CERTIFICATE_PRESETS.tigrisCoffee.registryNumber);
                                handleDatabaseSearch(MOCK_CERTIFICATE_PRESETS.tigrisCoffee.registryNumber);
                              }}
                              className="text-amber-500 hover:text-amber-400 font-semibold font-mono flex items-center gap-1 transition"
                            >
                              <span>Query Ledger</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        </div>

                        {/* 3. Dynamic Draft */}
                        <div className="p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className="font-mono text-xs font-bold text-amber-100 uppercase tracking-tight truncate max-w-[130px]" title={cert.trademarkNameEn}>
                                  {cert.trademarkNameEn || "Untitled Draft"}
                                </span>
                                <span className="text-[8px] bg-amber-500/20 text-amber-300 px-1 py-0.2 rounded font-mono uppercase shrink-0">Your Draft</span>
                              </div>
                              <span className="font-mono text-[9px] text-amber-500 font-bold bg-amber-500/20 px-2 py-0.5 rounded shrink-0 truncate max-w-[80px]" title={cert.registryNumber}>ID: {cert.registryNumber}</span>
                            </div>
                            <p className="font-amiri text-xs text-slate-400 leading-none truncate">{cert.trademarkNameAr || "علامة جديدة"}</p>
                          </div>

                          <div className="flex justify-between items-center gap-3 pt-2.5 mt-3 border-t border-amber-500/10 text-[10px]">
                            <button 
                              onClick={() => {
                                const url = getCompressedUrl(cert);
                                navigator.clipboard.writeText(url).then(() => {
                                  setCopiedRecentId('draft-cert');
                                  setTimeout(() => setCopiedRecentId(null), 2000);
                                });
                              }}
                              className="text-amber-305 hover:text-amber-200 font-mono flex items-center gap-1 transition"
                            >
                              <Copy className="w-3 h-3 text-amber-500/50" />
                              <span>{copiedRecentId === 'draft-cert' ? 'Copied Link!' : 'Copy Search Link'}</span>
                            </button>
                            <button 
                              onClick={() => {
                                setSearchQuery(cert.registryNumber);
                                handleDatabaseSearch(cert.registryNumber);
                              }}
                              className="text-amber-400 hover:text-amber-300 font-semibold font-mono flex items-center gap-1 transition"
                            >
                              <span>Query Ledger</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>

                {/* Scannable Verification Board */}
                <div className="pt-6 border-t border-slate-800/80 flex flex-col md:flex-row items-center gap-6">
                  <div className="w-24 h-24 bg-white p-1.5 rounded-xl border border-slate-700 flex items-center justify-center shadow-lg relative shrink-0">
                    <QRCodeSVG 
                      value={getVerificationUrl()}
                      size={75}
                      bgColor="#ffffff"
                      fgColor="#042F1A"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs font-bold text-slate-300 font-mono block">LIVE CAMERA SCANNING PORTAL</span>
                    <p className="text-xs text-slate-400 leading-relaxed max-w-xl">
                      The active brand you design in the sandbox remains cryptographically tied to the QR code above. Any device scanning the QR code will bypass the search bar and launch the certificate verification interface directly.
                    </p>
                  </div>
                </div>

                <div className="border-t border-slate-800/80 pt-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-[10px] text-slate-500">
                    <Info className="w-3.5 h-3.5 text-slate-600 flex-shrink-0" />
                    <span>Using URL compression state serialization. Fully offline compatible registry simulation.</span>
                  </div>
                </div>
              </motion.div>
            ) : (
              /* AUTOMATIC DATABASE RECORD & SYNC SCHEMATIC (iraqtradmarkdatabes.org) */
              <motion.div
                key="database-pane"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 text-slate-200"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-850">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-center text-amber-500 shrink-0">
                      <Database className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-slate-100 font-bold text-sm uppercase tracking-wider font-mono flex items-center gap-2">
                        <span>Online Database Preparation Center</span>
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded-full font-sans">Sync Ready</span>
                      </h3>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">
                        Automatic record generation targeting: <span className="text-amber-400">{window.location.host}</span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-emerald-950/10 border border-emerald-500/20 rounded-xl flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="text-xs space-y-1">
                    <p className="font-bold text-emerald-400 uppercase tracking-wider font-mono">Bilingual Synchronization Status: Active</p>
                    <p className="text-slate-300 leading-relaxed">
                      This system automatically structures and stages trademark registry credentials for instant replication in the online database of <strong>{window.location.host}</strong>.
                    </p>
                  </div>
                </div>

                {/* Schema JSON Viewer Panel */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold uppercase font-mono text-slate-400 tracking-wider">
                      Structured Database Record (JSON schema)
                    </span>
                    <button 
                      onClick={() => {
                        const jsonStr = JSON.stringify({
                          id: cert.registryNumber || "N/A",
                          proprietor: cert.ownerNameEn || "N/A",
                          trademark: cert.trademarkNameEn || "N/A",
                          class: cert.niceClass || 1,
                          goods_services: cert.goodsDescriptionEn || "N/A",
                          application_date: cert.applicationDate || "N/A",
                          registration_date: cert.registrationDate || "N/A",
                          validity_date: cert.expiryDate || "N/A",
                          address: cert.ownerAddressEn || "N/A"
                        }, null, 2);
                        navigator.clipboard.writeText(jsonStr).then(() => {
                          setCopiedDatabaseJson(true);
                          setTimeout(() => setCopiedDatabaseJson(false), 2000);
                        });
                      }}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                    >
                      <Copy className="w-3.5 h-3.5 animate-pulse" />
                      <span>{copiedDatabaseJson ? 'Copied JSON!' : 'Copy JSON Record'}</span>
                    </button>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 font-mono text-[11px] leading-relaxed relative overflow-hidden text-slate-300">
                    <pre className="max-h-[300px] overflow-y-auto whitespace-pre-wrap">
{JSON.stringify({
  id: cert.registryNumber || "N/A",
  proprietor: cert.ownerNameEn || "N/A",
  trademark: cert.trademarkNameEn || "N/A",
  class: cert.niceClass || 1,
  goods_services: cert.goodsDescriptionEn || "N/A",
  application_date: cert.applicationDate || "N/A",
  registration_date: cert.registrationDate || "N/A",
  validity_date: cert.expiryDate || "N/A",
  address: cert.ownerAddressEn || "N/A"
}, null, 2)}
                    </pre>
                  </div>
                </div>

                {/* QR Code and Lookup Target Settings */}
                <div className="bg-slate-950 p-5 rounded-xl border border-slate-850 space-y-4">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-amber-500 animate-bounce" />
                    <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-widest">
                      QR Code Link Target customizer
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    Choose what target URL path is embedded within the dynamic QR Code printed onto the certificate and ledger records:
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1.5">
                    <button 
                      onClick={() => setQrCodeOption('official')}
                      className={`p-3 rounded-lg border text-left transition space-y-1.5 flex flex-col justify-between ${qrCodeOption === 'official' ? 'bg-amber-500/10 border-amber-500/30 text-amber-250' : 'bg-slate-900/40 border-slate-850 hover:bg-slate-900/80 text-slate-400'}`}
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="font-mono text-xs font-bold">Official Iraq Database</span>
                        {qrCodeOption === 'official' && <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-mono uppercase">Official</span>}
                      </div>
                      <span className="text-[10px] font-mono leading-normal block truncate max-w-full">
                        {window.location.origin}/verify/{cert.registryNumber}
                      </span>
                    </button>

                    <button 
                      onClick={() => setQrCodeOption('testable')}
                      className={`p-3 rounded-lg border text-left transition space-y-1.5 flex flex-col justify-between ${qrCodeOption === 'testable' ? 'bg-amber-500/10 border-amber-500/30 text-amber-250' : 'bg-slate-900/40 border-slate-850 hover:bg-slate-900/80 text-slate-400'}`}
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="font-mono text-xs font-bold">Live Sandbox state link</span>
                        {qrCodeOption === 'testable' && <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-mono uppercase">Testable</span>}
                      </div>
                      <span className="text-[10px] font-mono leading-normal block truncate max-w-full">
                        [Encodes complete layout variables for on-phone live preview]
                      </span>
                    </button>
                  </div>
                </div>

                <div className="border-t border-slate-800/80 pt-4 flex items-center justify-between font-mono text-[10px] text-slate-500">
                  <div className="flex items-center gap-3">
                    <Info className="w-3.5 h-3.5 text-slate-650 flex-shrink-0" />
                    <span>Consistency check complete: All 9 structured schema keys match active certificate metrics perfectly.</span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Helpful system tips footer - Hidden in print */}
          <footer className="text-center text-xs text-slate-600 space-y-1 no-print mt-auto py-4">
            <p>Iraq Department of Trademark Protection • Industrial Design Authorization</p>
            <p>Designed for official scale printing on A4 portrait media. Select "Save as PDF" to preserve digital files.</p>
          </footer>

        </main>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
