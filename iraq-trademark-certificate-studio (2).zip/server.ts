import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize server-side Gemini client with proper telemetry headers
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// AI Autocomplete endpoint
app.post("/api/generate-certificate-details", async (req: express.Request, res: express.Response) => {
  try {
    const { brandName, ownerName, logoType } = req.body;
    
    if (!brandName) {
      res.status(400).json({ error: "Brand name is required." });
      return;
    }

    const cleanedOwnerName = ownerName || "Generic Owner Entity";
    const cleanedLogoType = logoType || "None";

    const systemInstruction = `You are an expert Registrar of intellectual property and trademark law for the Republic of Iraq (Ministry of Trade, Trademark Registration Department).
Your job is to take a trademark brand name, its owner name, and an optional logo motif, and auto-complete an official, highly authentic, fully bilingual (English and Arabic) trademark registration record.
Rules for dates & legalities in Iraq:
1. Use an Application Date (تاريخ تقديم الطلب) between 2018-01-01 and 2026-01-01.
2. Registration/Publication Date (تاريخ التسجيل) must be 4 to 8 months after the Application Date.
3. Expiry Date (تاريخ انتهاء الصلاحية) MUST be exactly 10 years from the Registration Date.
4. Nice Class (فئة تصنيف نيس): Correctly classify the business industry of the brand inside Nice Classes (integer between 1 and 45).
5. Goods Description (بين البضائع والخدمات): Build realistic, professional classification descriptions in English and Arabic that correspond to the brand's industry products.
6. Owner Legal Status & Nationality: Formulate professional designations (e.g. "Limited Liability Company" as "شركة ذات مسؤولية محدودة") and nationality (e.g. "Iraqi National Enterprise" as "منشأة وطنية عراقية" or matching foreigner nationality if appropriate).
7. Registrar: Choose a realistic registrar name in English/Arabic (e.g., "Adnan M. Al-Khafaji" / "عدنان محمد الخفاجي" or creative Iraq Ministry officers).
8. Use authentic wording like "العلامات والبيانات التجارية بجمهورية العراق".`;

    const prompt = `Generate a detailed bilingual trademark registration for the Iraq trademark office with:
Brand Name: "${brandName}"
Owner Name: "${cleanedOwnerName}"
Logo Motif: "${cleanedLogoType}"

Make the Arabic name translation highly accurate and natural. Translate the owner name accurately into Arabic.
Invent appropriate official registry numbers (e.g. 150000 to 180000 range), application numbers (e.g. 2019/5431 format), journal number, and page.
Select a highly appropriate Nice Classification category (1-45).
Create a rich, elegant goods description matching that Nice category in both English and Arabic.

Please return JSON matching this schema structure:
{
  registryNumber: string, // e.g. "164829"
  applicationNumber: string, // e.g. "2021/4829"
  applicationDate: string, // YYYY-MM-DD
  registrationDate: string, // YYYY-MM-DD
  expiryDate: string, // YYYY-MM-DD
  journalNumber: string,
  journalPageNumber: string,
  trademarkNameEn: string, // uppercase representation of Brand Name
  trademarkNameAr: string, // Arabic translation or transliteration of Brand Name
  trademarkType: string, // "Word" | "Device" | "Composite"
  trademarkTypeAr: string, // Arabic for trademarkType, e.g. "مشتركة (لفظية ورسمية)" or "رسمية"
  niceClass: number, // 1 to 45
  goodsDescriptionEn: string,
  goodsDescriptionAr: string,
  ownerNameEn: string,
  ownerNameAr: string,
  ownerNationalityEn: string,
  ownerNationalityAr: string,
  ownerAddressEn: string,
  ownerAddressAr: string,
  ownerLegalStatusEn: string,
  ownerLegalStatusAr: string,
  registrarNameEn: string,
  registrarNameAr: string,
  registrarTitleEn: string,
  registrarTitleAr: string,
  securityHash: string // high-entropy security hash, e.g. IQ-TM-[appNum]-[registryNum]-...
}`;

    // Call Gemini with structured response parameters
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            registryNumber: { type: Type.STRING },
            applicationNumber: { type: Type.STRING },
            applicationDate: { type: Type.STRING },
            registrationDate: { type: Type.STRING },
            expiryDate: { type: Type.STRING },
            journalNumber: { type: Type.STRING },
            journalPageNumber: { type: Type.STRING },
            trademarkNameEn: { type: Type.STRING },
            trademarkNameAr: { type: Type.STRING },
            trademarkType: { type: Type.STRING },
            trademarkTypeAr: { type: Type.STRING },
            niceClass: { type: Type.INTEGER },
            goodsDescriptionEn: { type: Type.STRING },
            goodsDescriptionAr: { type: Type.STRING },
            ownerNameEn: { type: Type.STRING },
            ownerNameAr: { type: Type.STRING },
            ownerNationalityEn: { type: Type.STRING },
            ownerNationalityAr: { type: Type.STRING },
            ownerAddressEn: { type: Type.STRING },
            ownerAddressAr: { type: Type.STRING },
            ownerLegalStatusEn: { type: Type.STRING },
            ownerLegalStatusAr: { type: Type.STRING },
            registrarNameEn: { type: Type.STRING },
            registrarNameAr: { type: Type.STRING },
            registrarTitleEn: { type: Type.STRING },
            registrarTitleAr: { type: Type.STRING },
            securityHash: { type: Type.STRING }
          },
          required: [
            "registryNumber", "applicationNumber", "applicationDate", "registrationDate", "expiryDate",
            "journalNumber", "journalPageNumber", "trademarkNameEn", "trademarkNameAr",
            "trademarkType", "trademarkTypeAr", "niceClass", "goodsDescriptionEn", "goodsDescriptionAr",
            "ownerNameEn", "ownerNameAr", "ownerNationalityEn", "ownerNationalityAr",
            "ownerAddressEn", "ownerAddressAr", "ownerLegalStatusEn", "ownerLegalStatusAr",
            "registrarNameEn", "registrarNameAr", "registrarTitleEn", "registrarTitleAr", "securityHash"
          ]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Empty response from Gemini model.");
    }

    const data = JSON.parse(textOutput.trim());
    res.json(data);
  } catch (err: any) {
    console.error("AI Generation Error:", err);
    res.status(500).json({ error: "Failed to generate authentic trademark data. Please try again.", details: err?.message });
  }
});

// Configure Vite or Static Servers
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Support wildcard routing for React SPAs
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
